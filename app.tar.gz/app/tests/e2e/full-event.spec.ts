import { expect, test, type Browser, type Page } from "@playwright/test";

const ADMIN_USER = process.env.E2E_ADMIN_USERNAME;
const ADMIN_PASS = process.env.E2E_ADMIN_PASSWORD;

test.skip(!ADMIN_USER || !ADMIN_PASS, "Set E2E_ADMIN_USERNAME and E2E_ADMIN_PASSWORD to run end-to-end tests.");

const QUIZ_TEXT = `
1. What is 6 × 7?
A) 36
B) 42
C) 48
D) 56

2. Which number is prime?
A) 21
B) 27
C) 29
D) 33

ANSWER KEY
1. B — 6 × 7 = 42.
2. C — 29 has no divisors other than 1 and itself.
`;

async function signIn(page: Page) {
  await page.goto("/admin/login");
  await page.getByLabel("Username").fill(ADMIN_USER!);
  await page.getByLabel("Password").fill(ADMIN_PASS!);
  await page.getByRole("button", { name: "Sign in" }).click();
  await expect(page).toHaveURL(/\/admin$/);
}

async function teamPage(browser: Browser) {
  const context = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });
  return context.newPage();
}

async function joinAs(page: Page, pin: string, name: string) {
  await page.goto("/join");
  await page.getByLabel("Game PIN").fill(pin);
  await page.getByRole("button", { name: "Continue" }).click();
  await page.getByLabel("Team name").fill(name);
  await page.getByRole("button", { name: "Join game" }).click();
}

test("protects admin pages and APIs", async ({ page, request }) => {
  await page.goto("/admin/quizzes");
  await expect(page).toHaveURL(/\/admin\/login$/);
  const res = await request.post("/api/admin/quizzes", { data: {}, headers: { origin: "http://localhost:3000" } });
  expect(res.status()).toBe(401);
  const forged = await request.post("/api/admin/login", { data: { username: "x", password: "y" }, headers: { origin: "https://evil.example" } });
  expect(forged.status()).toBe(403);
});

test("a full event: build a quiz, run a game, teams answer, results export", async ({ browser }) => {
  const stamp = Date.now().toString(36);
  const admin = await (await browser.newContext({ acceptDownloads: true })).newPage();
  await signIn(admin);

  // ── Build and publish a quiz by importing text ──
  await admin.goto("/admin/quizzes/new");
  await admin.getByLabel("Title").fill(`E2E quiz ${stamp}`);
  await admin.getByRole("button", { name: "Import questions" }).click();
  await admin.getByRole("dialog").locator("textarea").fill(QUIZ_TEXT);
  await admin.getByRole("button", { name: "Add 2 questions" }).click();
  await admin.getByRole("radio", { name: /Custom timing/ }).check();
  for (const input of await admin.getByLabel("Time limit (s)").all()) await input.fill("10");
  await admin.getByRole("button", { name: "Publish", exact: true }).click();
  await expect(admin.getByText("Published. You can now create a game from this quiz.")).toBeVisible();
  await expect(admin).toHaveURL(/\/admin\/quizzes\/[a-z0-9]+$/);

  // ── Create a game ──
  await admin.goto("/admin/games");
  await admin.getByLabel("Quiz", { exact: true }).selectOption({ label: `E2E quiz ${stamp} (2 questions)` });
  await admin.getByLabel("Results shown (s)").fill("3");
  await admin.getByRole("button", { name: "Create game and open registration" }).click();
  await expect(admin).toHaveURL(/\/admin\/games\/[a-z0-9]+$/);
  const sessionId = admin.url().split("/").pop()!;
  const pin = (await admin.getByTestId("game-pin").innerText()).replace(/\s/g, "");
  expect(pin).toMatch(/^\d{8}$/);

  // ── Presentation screen (public) ──
  const screen = await (await browser.newContext({ viewport: { width: 1600, height: 900 } })).newPage();
  await screen.goto(`/present/${sessionId}`);
  await expect(screen.getByText("Scan to join")).toBeVisible();

  // ── Teams join on phones ──
  const alpha = await teamPage(browser);
  await joinAs(alpha, pin, `Alpha ${stamp}`);
  await expect(alpha.getByText("You’re in.")).toBeVisible();

  const beta = await teamPage(browser);
  await joinAs(beta, pin, `alpha   ${stamp.toUpperCase()}`); // same name, different case/spacing
  await expect(beta.getByText(/already taken in this game/)).toBeVisible();
  await beta.getByLabel("Team name").fill(`Beta ${stamp}`);
  await beta.getByRole("button", { name: "Join game" }).click();
  await expect(beta.getByText("You’re in.")).toBeVisible();

  await expect(screen.getByText(`Alpha ${stamp}`)).toBeVisible();
  await expect(admin.getByText(`Beta ${stamp}`)).toBeVisible();

  // ── Start: no further admin clicks are needed between questions ──
  await admin.getByRole("button", { name: "Start game" }).click();
  await expect(alpha.getByText("What is 6 × 7?")).toBeVisible();
  await expect(screen.getByText("What is 6 × 7?")).toBeVisible();
  await expect(alpha.getByText("Tap one answer.")).toBeVisible();

  await alpha.getByRole("button", { name: /Answer B/ }).click();
  await expect(alpha.getByText("Answer submitted")).toBeVisible();
  await expect(alpha.getByRole("button", { name: /Answer A/ })).toBeDisabled();
  await beta.getByRole("button", { name: /Answer A/ }).click();
  await expect(beta.getByText("Answer submitted")).toBeVisible();
  await expect(screen.getByText("teams have answered")).toBeVisible();

  // Refreshing restores the same team and its locked answer.
  await alpha.reload();
  await expect(alpha.getByText("Answer submitted")).toBeVisible();
  await expect(alpha.getByText(`Alpha ${stamp}`)).toBeVisible();

  // The deadline passes on its own; results appear.
  await expect(alpha.getByText("Correct", { exact: true })).toBeVisible({ timeout: 20_000 });
  await expect(beta.getByText("Not this time")).toBeVisible();
  await expect(screen.getByText("Leaderboard")).toBeVisible();

  // Question 2 opens automatically.
  await expect(alpha.getByText("Which number is prime?")).toBeVisible({ timeout: 15_000 });
  await expect(alpha.getByText("Q 2/2")).toBeVisible();
  await beta.getByRole("button", { name: /Answer C/ }).click();
  // Alpha deliberately does not answer.

  await expect(alpha.getByText("That’s a wrap")).toBeVisible({ timeout: 30_000 });
  await expect(screen.getByText("Final results")).toBeVisible();
  await expect(alpha.getByText("No answer")).toHaveCount(0);

  // ── Results and CSV export (admin only) ──
  await admin.goto(`/admin/results/${sessionId}`);
  await expect(admin.getByRole("cell", { name: `Alpha ${stamp}` })).toBeVisible();
  await expect(admin.getByRole("cell", { name: `Beta ${stamp}` })).toBeVisible();
  const csv = await admin.request.get(`/api/admin/sessions/${sessionId}/export?kind=rankings`);
  expect(csv.status()).toBe(200);
  expect(csv.headers()["content-type"]).toContain("text/csv");
  const body = await csv.text();
  expect(body).toContain("Rank,Team,Score");
  expect(body).toContain(`Alpha ${stamp}`);

  // Teams and the public cannot export.
  const teamCsv = await alpha.request.get(`/api/admin/sessions/${sessionId}/export?kind=rankings`);
  expect(teamCsv.status()).toBe(401);
});
