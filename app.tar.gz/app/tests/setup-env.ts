// Integration tests run against a separate database so they never touch event data.
process.env.DATABASE_URL = process.env.TEST_DATABASE_URL ?? "postgresql://aic:aic_local_dev@localhost:5432/aic_quiz_test";
process.env.REALTIME_LOG = "silent";
process.env.REALTIME_SHARED_SECRET ??= "integration-test-secret-0123456789abcdef";
