import fs from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";
import { signInternal, signTicket, verifyInternal, verifyTicket } from "@/lib/realtime/ticket";
import { toCsv, formatCell } from "@/lib/csv";
import { blankQuestion, normalizeQuiz, quizInputSchema, validateQuizForPublish, type QuizInput } from "@/lib/validation/quiz";
import { parseTextQuiz } from "@/lib/import/text-quiz";
import { hashPassword, passwordProblem, verifyPassword } from "@/lib/auth/password";

const SECRET = "test-secret-0123456789-0123456789-abcdef";

describe("realtime tickets", () => {
  it("round-trips a team ticket", () => {
    const ticket = signTicket({ role: "team", teamId: "team1234567", sessionId: "sess1234567" }, SECRET);
    expect(verifyTicket(ticket, SECRET)).toMatchObject({ role: "team", teamId: "team1234567", sessionId: "sess1234567" });
  });

  it("rejects tampered, foreign-key and expired tickets", () => {
    const ticket = signTicket({ role: "admin", adminSessionId: "adm12345678" }, SECRET);
    const [body, sig] = ticket.split(".");
    const forged = Buffer.from(JSON.stringify({ ...JSON.parse(Buffer.from(body, "base64url").toString()), adminSessionId: "other" })).toString("base64url");
    expect(verifyTicket(`${forged}.${sig}`, SECRET)).toBeNull();
    expect(verifyTicket(ticket, `${SECRET}x`)).toBeNull();
    expect(verifyTicket(ticket, SECRET, Date.now() + 61_000)).toBeNull();
    expect(verifyTicket("garbage", SECRET)).toBeNull();
    expect(verifyTicket(undefined, SECRET)).toBeNull();
  });

  it("verifies signed internal notifications and rejects replays outside the window", () => {
    const body = JSON.stringify({ type: "session.updated", sessionId: "abc" });
    const { ts, signature } = signInternal(body, SECRET);
    expect(verifyInternal(body, ts, signature, SECRET)).toBe(true);
    expect(verifyInternal(body + " ", ts, signature, SECRET)).toBe(false);
    expect(verifyInternal(body, ts, signature, SECRET, Number(ts) + 60_000)).toBe(false);
  });
});

describe("CSV export", () => {
  it("escapes quotes, commas and newlines", () => {
    expect(toCsv([["a,b", 'say "hi"', "line\nbreak", 3, null]])).toBe('"a,b","say ""hi""","line\nbreak",3,\r\n');
  });

  it("neutralises spreadsheet formulas", () => {
    expect(formatCell("=HYPERLINK(\"x\")")).toBe("\"'=HYPERLINK(\"\"x\"\")\"");
    expect(formatCell("+1")).toBe("'+1");
    expect(formatCell("@cmd")).toBe("'@cmd");
    expect(formatCell(-5)).toBe("-5");
  });
});

describe("quiz validation", () => {
  const valid: QuizInput = {
    title: "Round 1",
    description: "",
    timingMode: "STANDARD",
    scoringMode: "SPEED",
    questions: [{ ...blankQuestion(), text: "2 + 2?", choices: ["3", "4", "5", "6"], correctIndex: 1 }],
  };

  it("accepts a complete quiz", () => {
    expect(validateQuizForPublish(valid)).toEqual([]);
  });

  it("flags empty text, empty choices, missing correct answer and an empty quiz", () => {
    const issues = validateQuizForPublish({ ...valid, questions: [{ ...blankQuestion(), choices: ["a", "", "c", "d"] }] });
    expect(issues.map((i) => i.field).sort()).toEqual(["choices.1", "correctIndex", "text"]);
    expect(validateQuizForPublish({ ...valid, questions: [] })[0].field).toBe("questions");
  });

  it("forces 60 seconds in standard mode", () => {
    const normalized = normalizeQuiz({ ...valid, questions: [{ ...valid.questions[0], timeLimitSec: 20 }] });
    expect(normalized.questions[0].timeLimitSec).toBe(60);
    expect(validateQuizForPublish({ ...valid, questions: [{ ...valid.questions[0], timeLimitSec: 20 }] })[0].field).toBe("timeLimitSec");
    expect(validateQuizForPublish({ ...valid, timingMode: "CUSTOM", questions: [{ ...valid.questions[0], timeLimitSec: 20 }] })).toEqual([]);
  });

  it("rejects out-of-range values at the schema level", () => {
    expect(quizInputSchema.safeParse({ ...valid, questions: [{ ...valid.questions[0], points: -1 }] }).success).toBe(false);
    expect(quizInputSchema.safeParse({ ...valid, questions: [{ ...valid.questions[0], timeLimitSec: 5 }] }).success).toBe(false);
    expect(quizInputSchema.safeParse({ ...valid, questions: [{ ...valid.questions[0], choices: ["a", "b", "c", "d", "e"] }] }).success).toBe(false);
  });
});

describe("text quiz import", () => {
  // The quiz file holds the answer key, so it lives in the git-ignored private/ folder.
  const mathsFile = path.join(__dirname, "../../private/advanced-maths-quiz.txt");
  it.skipIf(!fs.existsSync(mathsFile))("parses the organisers' 30-question maths quiz with its answer key", () => {
    const text = fs.readFileSync(mathsFile, "utf8");
    const parsed = parseTextQuiz(text);
    expect(parsed.warnings).toEqual([]);
    expect(parsed.questions).toHaveLength(30);
    const letters = parsed.questions.map((q) => String.fromCharCode(65 + q.correctIndex)).join("");
    expect(letters).toBe("BCCBBACBCABBBCBBCDBDCCBCCCCCCA");
    expect(parsed.questions[9].choices).toEqual(["34,650", "69,300", "11!/2!", "39,916,800"]);
    expect(parsed.questions[0].explanation).toContain("35 + 13 = 48");
    expect(validateQuizForPublish({ title: "x", description: "", timingMode: "STANDARD", scoringMode: "SPEED", questions: parsed.questions })).toEqual([]);
  });

  it("detects true/false questions and reports missing keys", () => {
    const parsed = parseTextQuiz("1. The sky is blue.\nA) True\nB) False\n2. Pick one\nA) x\nB) y\nANSWER KEY\n1. A");
    expect(parsed.questions[0].type).toBe("TRUE_FALSE");
    expect(parsed.questions[1].correctIndex).toBe(-1);
    expect(parsed.warnings[0]).toMatch(/Question 2/);
  });
});

describe("admin passwords", () => {
  it("hashes with Argon2id and verifies", async () => {
    const hash = await hashPassword("correct horse battery staple");
    expect(hash.startsWith("$argon2id$")).toBe(true);
    expect(await verifyPassword(hash, "correct horse battery staple")).toBe(true);
    expect(await verifyPassword(hash, "wrong")).toBe(false);
    expect(await verifyPassword("not-a-hash", "x")).toBe(false);
  });

  it("rejects weak passwords", () => {
    expect(passwordProblem("short")).toMatch(/at least/);
    expect(passwordProblem("aaaaaaaaaaaaaaaa")).toMatch(/repetitive/);
    expect(passwordProblem("host-password-2026", "host")).toMatch(/username/);
    expect(passwordProblem("a fine long passphrase")).toBeNull();
  });
});
