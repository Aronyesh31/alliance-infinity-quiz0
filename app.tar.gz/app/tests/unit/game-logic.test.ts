import { describe, expect, it } from "vitest";
import { computePoints } from "@/lib/game/scoring";
import { rankTeams } from "@/lib/game/ranking";
import { formatPin, generatePin, normalizePin } from "@/lib/game/pin";
import { normalizeTeamName } from "@/lib/game/team-name";
import { joinAvailability } from "@/lib/join";

describe("scoring", () => {
  const base = { maxPoints: 1000, timeLimitMs: 60_000, mode: "SPEED" as const };

  it("awards full points for an instant correct answer and half at the buzzer", () => {
    expect(computePoints({ ...base, isCorrect: true, responseMs: 0 })).toBe(1000);
    expect(computePoints({ ...base, isCorrect: true, responseMs: 30_000 })).toBe(750);
    expect(computePoints({ ...base, isCorrect: true, responseMs: 60_000 })).toBe(500);
  });

  it("never awards points for wrong answers and never goes negative", () => {
    expect(computePoints({ ...base, isCorrect: false, responseMs: 1000 })).toBe(0);
    expect(computePoints({ ...base, isCorrect: true, responseMs: 999_999 })).toBe(500);
    expect(computePoints({ ...base, isCorrect: true, responseMs: -50 })).toBe(1000);
    expect(computePoints({ ...base, maxPoints: 0, isCorrect: true, responseMs: 0 })).toBe(0);
  });

  it("gives full points regardless of speed in accuracy mode", () => {
    expect(computePoints({ ...base, mode: "ACCURACY", isCorrect: true, responseMs: 59_000 })).toBe(1000);
  });
});

describe("ranking", () => {
  const t = (id: string, score: number, correctCount: number, correctTimeMs: number, joinedAt = 0) => ({ id, name: id, score, correctCount, correctTimeMs, joinedAt });

  it("orders by score, then correct answers, then time on correct answers", () => {
    const ranked = rankTeams([t("slow", 900, 3, 9000), t("top", 1000, 2, 5000), t("fast", 900, 3, 4000), t("few", 900, 2, 1000)]);
    expect(ranked.map((r) => [r.id, r.rank])).toEqual([
      ["top", 1],
      ["fast", 2],
      ["slow", 3],
      ["few", 4],
    ]);
  });

  it("shares a rank only on an exact tie", () => {
    const ranked = rankTeams([t("a", 500, 1, 100, 1), t("b", 500, 1, 100, 2), t("c", 400, 1, 50)]);
    expect(ranked.map((r) => r.rank)).toEqual([1, 1, 3]);
  });
});

describe("game PIN", () => {
  it("generates 8-digit PINs that never start with zero", () => {
    for (let i = 0; i < 2000; i++) {
      const pin = generatePin();
      expect(pin).toMatch(/^[1-9]\d{7}$/);
    }
  });

  it("normalises spaced input and rejects bad shapes", () => {
    expect(normalizePin("1234 5678")).toBe("12345678");
    expect(normalizePin("1234-5678")).toBe("12345678");
    expect(normalizePin("01234567")).toBeNull();
    expect(normalizePin("1234567")).toBeNull();
    expect(normalizePin("abcd5678")).toBeNull();
    expect(normalizePin(12345678)).toBeNull();
    expect(formatPin("12345678")).toBe("1234 5678");
  });
});

describe("team names", () => {
  it("trims and collapses whitespace", () => {
    expect(normalizeTeamName("   Team    Alpha  ")).toEqual({ ok: true, name: "Team Alpha", key: "teamalpha" });
  });

  it("treats case, spacing and punctuation variants as the same name", () => {
    const keys = ["A-Team", "a team", "ATEAM", "a.team!"].map((n) => {
      const r = normalizeTeamName(n);
      return r.ok ? r.key : null;
    });
    expect(new Set(keys).size).toBe(1);
  });

  it("strips invisible characters used to fake duplicates", () => {
    const r = normalizeTeamName("Te​am  Alpha");
    expect(r.ok && r.key).toBe("teamalpha");
  });

  it("rejects markup, empty and over-long names", () => {
    expect(normalizeTeamName("<script>alert(1)</script>").ok).toBe(false);
    expect(normalizeTeamName("<b>Bold</b>").ok).toBe(false);
    expect(normalizeTeamName("   ").ok).toBe(false);
    expect(normalizeTeamName("x").ok).toBe(false);
    expect(normalizeTeamName("y".repeat(25)).ok).toBe(false);
    expect(normalizeTeamName("=SUM(A1)").ok).toBe(false);
    expect(normalizeTeamName(42).ok).toBe(false);
  });

  it("accepts non-English names", () => {
    const r = normalizeTeamName("गणित टीम");
    expect(r.ok).toBe(true);
  });
});

describe("join availability", () => {
  const open = { state: "LOBBY" as const, registrationOpen: true, allowLateJoin: false, teamCount: 10, capacity: 400 };
  it("accepts teams in an open lobby", () => expect(joinAvailability(open).ok).toBe(true));
  it("rejects when full, closed, started or finished", () => {
    expect(joinAvailability({ ...open, teamCount: 400 })).toMatchObject({ ok: false, code: "full" });
    expect(joinAvailability({ ...open, registrationOpen: false })).toMatchObject({ ok: false, code: "closed" });
    expect(joinAvailability({ ...open, state: "QUESTION" })).toMatchObject({ ok: false, code: "started" });
    expect(joinAvailability({ ...open, state: "FINISHED" })).toMatchObject({ ok: false, code: "finished" });
    expect(joinAvailability({ ...open, state: "QUESTION", allowLateJoin: true }).ok).toBe(true);
  });
});
