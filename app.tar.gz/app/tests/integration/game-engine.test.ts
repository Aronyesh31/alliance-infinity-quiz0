import { afterAll, afterEach, beforeEach, describe, expect, it } from "vitest";
import { prisma } from "@/lib/db";
import { signTicket } from "@/lib/realtime/ticket";
import type { PublicSnapshot } from "@/lib/realtime/protocol";
import type { RealtimeServer } from "../../realtime/app";
import { adminClient, client, connected, makeGame, resetDb, SECRET, sleep, startServer, submit, teamClient, type Client } from "./helpers";

let server: RealtimeServer | null = null;
let clients: Client[] = [];

beforeEach(async () => {
  await resetDb();
});

afterEach(async () => {
  for (const c of clients) c.socket.disconnect();
  clients = [];
  await server?.close();
  server = null;
});

afterAll(async () => {
  await prisma.$disconnect();
});

const track = <T extends Client>(c: T) => {
  clients.push(c);
  return c;
};

describe("server-authoritative game flow", () => {
  it("runs every question on the server clock, advances automatically and scores on the server", async () => {
    const TEAMS = 30;
    const questions = [
      { timeLimitSec: 2, correctIndex: 1 },
      { timeLimitSec: 2, correctIndex: 3 },
      { timeLimitSec: 2, correctIndex: 0 },
    ];
    const { session, teams, adminSession } = await makeGame({ questions, teams: TEAMS, revealSeconds: 1 });
    const started = await startServer();
    server = started.server;

    const teamClients = teams.map((t) => track(teamClient(started.url, t.id, session.id)));
    await Promise.all(teamClients.map(connected));
    const admin = track(await adminClient(started.url, adminSession.id, session.id));

    const acks: { team: number; q: number; result: Awaited<ReturnType<typeof submit>> }[] = [];
    const leaks: string[] = [];
    teamClients.forEach((c, i) => {
      const answered = new Set<number>();
      c.socket.on("state", async (s: PublicSnapshot) => {
        // The correct answer must never travel to a team while a question is open.
        if (s.state === "QUESTION" && (s.reveal !== null || JSON.stringify(s).includes("correctIndex"))) leaks.push(`team ${i} q ${s.currentIndex}`);
        if (s.state !== "QUESTION" || answered.has(s.currentIndex)) return;
        answered.add(s.currentIndex);
        const q = s.currentIndex;
        if (i === 29) return; // one team never answers
        await new Promise((r) => setTimeout(r, Math.floor(Math.random() * 1200)));
        if (i === 1) acks.push({ team: i, q, result: await submit(c, q, 7) }); // invalid choice
        if (i === 2) acks.push({ team: i, q, result: await submit(c, q + 1, 0) }); // wrong question
        const result = await submit(c, q, i % 4);
        acks.push({ team: i, q, result });
        if (i === 0) acks.push({ team: i, q, result: await submit(c, q, (i + 1) % 4) }); // second answer
      });
    });

    const start = await admin.command({ type: "start" });
    expect(start.ok).toBe(true);
    await admin.waitFor((s) => s.state === "FINISHED", 30_000);
    await sleep(200);

    expect(leaks).toEqual([]);

    // Exact sequence for a team, with no admin action between questions.
    const seq = teamClients[5].states.map((s) => `${s.state}:${s.currentIndex}`).filter((v, i, a) => v !== a[i - 1]);
    expect(seq).toEqual(["LOBBY:-1", "QUESTION:0", "REVEAL:0", "QUESTION:1", "REVEAL:1", "QUESTION:2", "REVEAL:2", "FINISHED:2"]);

    // Deadlines are exactly the time limit; results arrive promptly after the deadline.
    for (let q = 0; q < questions.length; q++) {
      const open = teamClients[5].states.find((s) => s.state === "QUESTION" && s.currentIndex === q)!;
      expect(open.deadline! - open.questionStartedAt!).toBe(questions[q].timeLimitSec * 1000);
      const revealSeenAt = teamClients[5].receivedAt.get(`REVEAL:${q}`)!;
      expect(revealSeenAt).toBeGreaterThanOrEqual(open.deadline! - 5);
      expect(revealSeenAt - open.deadline!).toBeLessThan(400);
      const reveal = teamClients[5].states.find((s) => s.state === "REVEAL" && s.currentIndex === q)!;
      expect(reveal.reveal?.correctIndex).toBe(questions[q].correctIndex);
      // The next question opens revealSeconds after the results.
      if (q + 1 < questions.length) {
        const next = teamClients[5].states.find((s) => s.state === "QUESTION" && s.currentIndex === q + 1)!;
        expect(next.questionStartedAt! - reveal.revealEndsAt!).toBeGreaterThanOrEqual(0);
        expect(next.questionStartedAt! - reveal.revealEndsAt!).toBeLessThan(400);
      }
    }

    // Acknowledgements
    const first = (team: number, q: number) => acks.filter((a) => a.team === team && a.q === q);
    for (let q = 0; q < 3; q++) {
      expect(first(1, q)[0].result).toMatchObject({ ok: false, code: "invalid_choice" });
      expect(first(2, q)[0].result).toMatchObject({ ok: false, code: "wrong_question" });
      const zero = first(0, q);
      expect(zero[0].result).toMatchObject({ ok: true, choiceIndex: 0 });
      expect(zero[1].result).toMatchObject({ ok: true, choiceIndex: 0, duplicate: true });
    }

    // Database: one answer per team per question, server-computed points, no negatives.
    const answers = await prisma.answer.findMany({ where: { sessionId: session.id } });
    expect(answers).toHaveLength((TEAMS - 1) * questions.length);
    const pairs = new Set(answers.map((a) => `${a.teamId}:${a.questionIndex}`));
    expect(pairs.size).toBe(answers.length);
    for (const a of answers) {
      const q = questions[a.questionIndex];
      expect(a.isCorrect).toBe(a.choiceIndex === q.correctIndex);
      if (!a.isCorrect) expect(a.points).toBe(0);
      else {
        expect(a.points).toBeGreaterThanOrEqual(500);
        expect(a.points).toBeLessThanOrEqual(1000);
        expect(a.points).toBe(Math.round(1000 * (1 - Math.min(1, a.responseMs / 2000) / 2)));
      }
      expect(a.responseMs).toBeLessThanOrEqual(2000);
    }

    const dbTeams = await prisma.team.findMany({ where: { sessionId: session.id }, include: { answers: true } });
    for (const t of dbTeams) {
      expect(t.score).toBe(t.answers.reduce((s, a) => s + a.points, 0));
      expect(t.correctCount).toBe(t.answers.filter((a) => a.isCorrect).length);
      expect(t.finalRank).not.toBeNull();
    }
    const silent = dbTeams.find((t) => t.name === "Team 29")!;
    expect(silent.score).toBe(0);
    const best = dbTeams.reduce((a, b) => (b.score > a.score ? b : a));
    expect(best.finalRank).toBe(1);

    const final = admin.latest()!;
    expect(final.leaderboard?.[0].score).toBe(best.score);
    const sessionRow = await prisma.gameSession.findUniqueOrThrow({ where: { id: session.id } });
    expect(sessionRow.state).toBe("FINISHED");
    expect(sessionRow.endedAt).not.toBeNull();
  });

  it("pauses the clock for everyone and shifts the deadline on resume", async () => {
    const { session, teams, adminSession } = await makeGame({ questions: [{ timeLimitSec: 3, correctIndex: 2 }], teams: 2, revealSeconds: 1 });
    const started = await startServer();
    server = started.server;
    const team = track(teamClient(started.url, teams[0].id, session.id));
    await connected(team);
    const admin = track(await adminClient(started.url, adminSession.id, session.id));

    await admin.command({ type: "start" });
    const open = await team.waitFor((s) => s.state === "QUESTION");
    await sleep(800);
    expect((await admin.command({ type: "pause" })).ok).toBe(true);
    const paused = await team.waitFor((s) => s.state === "PAUSED");
    expect(paused.pausedRemainingMs).toBeGreaterThan(1900);
    expect(paused.pausedRemainingMs).toBeLessThanOrEqual(2250);
    expect(await submit(team, 0, 2)).toMatchObject({ ok: false, code: "closed" });

    await sleep(1500);
    const resumedAt = Date.now();
    expect((await admin.command({ type: "resume" })).ok).toBe(true);
    const resumed = await team.waitFor((s) => s.state === "QUESTION" && s.deadline !== open.deadline);
    expect(resumed.deadline! - resumedAt).toBeGreaterThan(1800);
    expect(resumed.deadline! - resumedAt).toBeLessThan(2400);
    // Elapsed time excludes the pause, so the window stays exactly the time limit.
    expect(resumed.deadline! - resumed.questionStartedAt!).toBe(3000);

    expect(await submit(team, 0, 2)).toMatchObject({ ok: true });
    const answer = await prisma.answer.findFirstOrThrow({ where: { teamId: teams[0].id } });
    expect(answer.responseMs).toBeGreaterThan(700);
    expect(answer.responseMs).toBeLessThan(1400);

    const reveal = await team.waitFor((s) => s.state === "REVEAL");
    expect(team.receivedAt.get("REVEAL:0")! - resumed.deadline!).toBeLessThan(400);
    expect(reveal.reveal?.answeredCount).toBe(1);
  });

  it("resumes a running question on schedule after a server restart", async () => {
    const { session, teams, adminSession } = await makeGame({ questions: [{ timeLimitSec: 3, correctIndex: 1 }], teams: 1, revealSeconds: 1 });
    const first = await startServer();
    const admin = track(await adminClient(first.url, adminSession.id, session.id));
    await admin.command({ type: "start" });
    const open = await admin.waitFor((s) => s.state === "QUESTION");
    await sleep(600);
    // Simulate a crash / redeploy.
    for (const c of clients) c.socket.disconnect();
    clients = [];
    await first.server.close();

    const second = await startServer();
    server = second.server;
    const team = track(teamClient(second.url, teams[0].id, session.id));
    const resumed = await team.waitFor((s) => s.state === "QUESTION");
    expect(resumed.deadline).toBe(open.deadline);
    expect(await submit(team, 0, 1)).toMatchObject({ ok: true });
    await team.waitFor((s) => s.state === "REVEAL");
    expect(team.receivedAt.get("REVEAL:0")! - open.deadline!).toBeLessThan(400);
    const events = await prisma.gameEvent.findMany({ where: { sessionId: session.id } });
    expect(events.some((e) => e.message.includes("restarted mid-question"))).toBe(true);
  });

  it("rejects answers after the deadline", async () => {
    const { session, teams, adminSession } = await makeGame({ questions: [{ timeLimitSec: 1, correctIndex: 0 }, { timeLimitSec: 5, correctIndex: 0 }], teams: 1, revealSeconds: 3 });
    const started = await startServer();
    server = started.server;
    const team = track(teamClient(started.url, teams[0].id, session.id));
    await connected(team);
    const admin = track(await adminClient(started.url, adminSession.id, session.id));
    await admin.command({ type: "start" });
    await team.waitFor((s) => s.state === "REVEAL");
    expect(await submit(team, 0, 0)).toMatchObject({ ok: false, code: "closed" });
    expect(await prisma.answer.count()).toBe(0);
  });
});

describe("realtime authorization", () => {
  it("refuses sockets without a valid ticket and teams that were removed", async () => {
    const { session, teams, adminSession } = await makeGame({ questions: [{ timeLimitSec: 5, correctIndex: 0 }], teams: 2 });
    const started = await startServer();
    server = started.server;

    const errorOf = (c: Client) => new Promise<string>((resolve) => c.socket.once("connect_error", (e) => resolve(e.message)));
    expect(await errorOf(track(client(started.url, {})))).toBe("unauthorized");
    expect(await errorOf(track(client(started.url, { ticket: signTicket({ role: "team", teamId: teams[0].id, sessionId: session.id }, "wrong-secret-wrong-secret-wrong-secret") })))).toBe("unauthorized");
    expect(await errorOf(track(client(started.url, { ticket: signTicket({ role: "admin", adminSessionId: "nosuchsession00" }, SECRET) })))).toBe("unauthorized");

    // A team socket cannot issue admin commands.
    const team = track(teamClient(started.url, teams[0].id, session.id));
    await connected(team);
    await expect(team.socket.timeout(800).emitWithAck("admin:command", { sessionId: session.id, command: { type: "start" } })).rejects.toThrow();

    const admin = track(await adminClient(started.url, adminSession.id, session.id));
    const removedEvent = new Promise<void>((resolve) => team.socket.once("team:removed", () => resolve()));
    expect((await admin.command({ type: "removeTeam", teamId: teams[0].id })).ok).toBe(true);
    await removedEvent;
    expect(await errorOf(track(teamClient(started.url, teams[0].id, session.id)))).toBe("team_removed");
    const row = await prisma.gameSession.findUniqueOrThrow({ where: { id: session.id } });
    expect(row.teamCount).toBe(1);

    // Revoked admin sessions lose control immediately.
    await prisma.adminSession.delete({ where: { id: adminSession.id } });
    expect(await admin.command({ type: "start" })).toMatchObject({ ok: false, code: "unauthorized" });
  });

  it("replaces an older connection when a team connects again", async () => {
    const { session, teams } = await makeGame({ questions: [{ timeLimitSec: 5, correctIndex: 0 }], teams: 1 });
    const started = await startServer();
    server = started.server;
    const a = track(teamClient(started.url, teams[0].id, session.id));
    await connected(a);
    const superseded = new Promise<void>((resolve) => a.socket.once("team:superseded", () => resolve()));
    const b = track(teamClient(started.url, teams[0].id, session.id));
    await connected(b);
    await superseded;
    expect(b.socket.connected).toBe(true);
  });
});
