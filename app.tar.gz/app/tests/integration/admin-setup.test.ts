import { afterAll, beforeEach, describe, expect, it } from "vitest";
import { prisma } from "@/lib/db";
import { createInitialAdmin, setupCodeConfigured } from "@/lib/auth/setup";
import { verifyPassword } from "@/lib/auth/password";
import { resetDb } from "./helpers";

const CODE = "setup-code-0123456789-abcdef";

beforeEach(async () => {
  await resetDb();
  process.env.ADMIN_SETUP_CODE = CODE;
});

afterAll(async () => {
  delete process.env.ADMIN_SETUP_CODE;
  await prisma.$disconnect();
});

describe("first-run admin setup", () => {
  it("is disabled without a long enough setup code", async () => {
    process.env.ADMIN_SETUP_CODE = "short";
    expect(setupCodeConfigured()).toBe(false);
    expect(await createInitialAdmin({ setupCode: "short", username: "host", password: "a fine long passphrase" })).toMatchObject({ ok: false, code: "disabled" });
  });

  it("rejects a wrong code, a bad username and a weak password", async () => {
    expect(await createInitialAdmin({ setupCode: "wrong", username: "host", password: "a fine long passphrase" })).toMatchObject({ ok: false, code: "bad_code" });
    expect(await createInitialAdmin({ setupCode: CODE, username: "x", password: "a fine long passphrase" })).toMatchObject({ ok: false, code: "bad_username" });
    expect(await createInitialAdmin({ setupCode: CODE, username: "host", password: "short" })).toMatchObject({ ok: false, code: "weak_password" });
    expect(await prisma.admin.count()).toBe(0);
  });

  it("creates exactly one admin, then refuses further setups", async () => {
    const first = await createInitialAdmin({ setupCode: CODE, username: "  Host ", password: "a fine long passphrase" });
    expect(first).toMatchObject({ ok: true, username: "host" });
    const admin = await prisma.admin.findUniqueOrThrow({ where: { id: 1 } });
    expect(await verifyPassword(admin.passwordHash, "a fine long passphrase")).toBe(true);

    expect(await createInitialAdmin({ setupCode: CODE, username: "intruder", password: "another long passphrase" })).toMatchObject({ ok: false, code: "done" });
    expect(await prisma.admin.count()).toBe(1);
  });

  it("allows only one winner when two setups race", async () => {
    const results = await Promise.all([
      createInitialAdmin({ setupCode: CODE, username: "first", password: "a fine long passphrase" }),
      createInitialAdmin({ setupCode: CODE, username: "second", password: "a fine long passphrase" }),
    ]);
    expect(results.filter((r) => r.ok)).toHaveLength(1);
    expect(await prisma.admin.count()).toBe(1);
  });
});
