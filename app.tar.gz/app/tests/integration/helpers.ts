import { io as connect, type Socket } from "socket.io-client";
import { prisma } from "@/lib/db";
import { signTicket } from "@/lib/realtime/ticket";
import { generatePin } from "@/lib/game/pin";
import { randomToken, sha256Hex } from "@/lib/security/tokens";
import { createRealtimeServer, type RealtimeServer } from "../../realtime/app";
import type { AdminCommand, Ack, PublicSnapshot, TeamSelf } from "@/lib/realtime/protocol";

export const SECRET = process.env.REALTIME_SHARED_SECRET!;
export const ORIGIN = "http://localhost:3000";

export async function resetDb() {
  await prisma.$executeRawUnsafe(
    `TRUNCATE "Answer","Team","SessionQuestion","GameEvent","GameSession","Question","Quiz","AdminSession","Admin","RateLimit","Image" CASCADE`,
  );
}

export interface QSpec {
  timeLimitSec: number;
  correctIndex: number;
  choices?: string[];
  points?: number;
}

export async function makeGame(opts: { questions: QSpec[]; teams: number; revealSeconds?: number; scoringMode?: "SPEED" | "ACCURACY" }) {
  const session = await prisma.gameSession.create({
    data: {
      pin: generatePin(),
      title: "Integration game",
      scoringMode: opts.scoringMode ?? "SPEED",
      questionCount: opts.questions.length,
      revealSeconds: opts.revealSeconds ?? 1,
      registrationOpen: true,
      teamCount: opts.teams,
      questions: {
        create: opts.questions.map((q, position) => ({
          position,
          type: "MULTIPLE_CHOICE",
          text: `Question ${position + 1}`,
          choices: q.choices ?? ["A", "B", "C", "D"],
          correctIndex: q.correctIndex,
          timeLimitSec: q.timeLimitSec,
          points: q.points ?? 1000,
        })),
      },
    },
  });
  const teams = [];
  for (let i = 0; i < opts.teams; i++) {
    teams.push(
      await prisma.team.create({
        data: { sessionId: session.id, name: `Team ${i}`, nameKey: `team${i}`, tokenHash: sha256Hex(randomToken()) },
      }),
    );
  }
  await prisma.admin.upsert({ where: { id: 1 }, create: { id: 1, username: "host", passwordHash: "x" }, update: {} });
  const adminSession = await prisma.adminSession.create({
    data: { adminId: 1, tokenHash: sha256Hex(randomToken()), expiresAt: new Date(Date.now() + 3600_000) },
  });
  return { session, teams, adminSession };
}

export async function startServer(): Promise<{ server: RealtimeServer; url: string }> {
  const server = createRealtimeServer({ port: 0, secret: SECRET, allowedOrigins: [ORIGIN], isLeader: () => true });
  const port = await server.listen();
  await server.onLeadershipAcquired();
  return { server, url: `http://localhost:${port}` };
}

export interface Client {
  socket: Socket;
  states: PublicSnapshot[];
  selves: TeamSelf[];
  receivedAt: Map<string, number>;
  latest: () => PublicSnapshot | undefined;
  waitFor: (pred: (s: PublicSnapshot) => boolean, timeoutMs?: number) => Promise<PublicSnapshot>;
}

export function client(url: string, auth: Record<string, unknown>): Client {
  const socket = connect(url, { auth, transports: ["websocket"], reconnection: false, extraHeaders: { origin: ORIGIN } });
  const states: PublicSnapshot[] = [];
  const selves: TeamSelf[] = [];
  const receivedAt = new Map<string, number>();
  const waiters: { pred: (s: PublicSnapshot) => boolean; resolve: (s: PublicSnapshot) => void }[] = [];
  socket.on("state", (s: PublicSnapshot) => {
    states.push(s);
    const key = `${s.state}:${s.currentIndex}`;
    if (!receivedAt.has(key)) receivedAt.set(key, Date.now());
    for (const w of [...waiters]) {
      if (w.pred(s)) {
        waiters.splice(waiters.indexOf(w), 1);
        w.resolve(s);
      }
    }
  });
  socket.on("team:self", (s: TeamSelf) => selves.push(s));
  return {
    socket,
    states,
    selves,
    receivedAt,
    latest: () => states[states.length - 1],
    waitFor: (pred, timeoutMs = 20_000) =>
      new Promise((resolve, reject) => {
        const last = states[states.length - 1];
        if (last && pred(last)) return resolve(last);
        const timer = setTimeout(() => reject(new Error("timed out waiting for state")), timeoutMs);
        waiters.push({
          pred,
          resolve: (s) => {
            clearTimeout(timer);
            resolve(s);
          },
        });
      }),
  };
}

export function teamClient(url: string, teamId: string, sessionId: string) {
  return client(url, { ticket: signTicket({ role: "team", teamId, sessionId }, SECRET) });
}

export async function adminClient(url: string, adminSessionId: string, sessionId: string) {
  const c = client(url, { ticket: signTicket({ role: "admin", adminSessionId }, SECRET) });
  await new Promise<void>((resolve, reject) => {
    c.socket.once("connect", () => resolve());
    c.socket.once("connect_error", reject);
  });
  const watch: Ack = await c.socket.timeout(5000).emitWithAck("admin:watch", { sessionId });
  if (!watch.ok) throw new Error(`watch failed: ${watch.message}`);
  return {
    ...c,
    command: (command: AdminCommand): Promise<Ack> => c.socket.timeout(10_000).emitWithAck("admin:command", { sessionId, command }),
  };
}

export function connected(c: Client) {
  return new Promise<void>((resolve, reject) => {
    if (c.socket.connected) return resolve();
    c.socket.once("connect", () => resolve());
    c.socket.once("connect_error", reject);
  });
}

export function submit(c: Client, questionIndex: number, choiceIndex: number): Promise<Ack<{ choiceIndex: number; duplicate?: boolean }>> {
  return c.socket.timeout(10_000).emitWithAck("answer:submit", { questionIndex, choiceIndex });
}

export const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
