// Single-leader guard. Only one realtime process may run game timers at a time,
// otherwise two servers could advance the same game. During a zero-downtime
// deploy the new instance waits here until the old one releases the lock.
import pg from "pg";
import { log } from "./log";

const LOCK_KEY = 772_026_001; // arbitrary constant shared by all instances

export interface LeaderLock {
  isLeader: () => boolean;
  /** Resolves once this process holds the lock. */
  acquired: Promise<void>;
  release: () => Promise<void>;
}

export function acquireLeaderLock(connectionString: string, onLost: () => void): LeaderLock {
  let leader = false;
  let stopped = false;
  let client: pg.Client | null = null;
  let keepAlive: NodeJS.Timeout | null = null;
  let resolveAcquired!: () => void;
  const acquired = new Promise<void>((r) => (resolveAcquired = r));

  const connect = async () => {
    // Advisory locks are session-scoped, so this must be a direct connection,
    // not a transaction-pooled one.
    client = new pg.Client({ connectionString, keepAlive: true });
    client.on("error", (err) => {
      log.error("leader lock connection error", { error: String(err) });
      if (leader && !stopped) {
        leader = false;
        onLost();
      }
    });
    await client.connect();
  };

  const tryLock = async (): Promise<void> => {
    while (!stopped) {
      try {
        if (!client) await connect();
        const res = await client!.query<{ locked: boolean }>("SELECT pg_try_advisory_lock($1) AS locked", [LOCK_KEY]);
        if (res.rows[0]?.locked) {
          leader = true;
          log.info("realtime leadership acquired");
          resolveAcquired();
          keepAlive = setInterval(() => {
            client?.query("SELECT 1").catch((err) => {
              log.error("leader keep-alive failed", { error: String(err) });
              if (leader && !stopped) {
                leader = false;
                onLost();
              }
            });
          }, 15_000);
          return;
        }
        log.info("another realtime instance holds leadership; waiting");
      } catch (error) {
        log.error("leader lock attempt failed", { error: String(error) });
        await client?.end().catch(() => {});
        client = null;
      }
      await new Promise((r) => setTimeout(r, 2000));
    }
  };

  void tryLock();

  return {
    isLeader: () => leader,
    acquired,
    release: async () => {
      stopped = true;
      if (keepAlive) clearInterval(keepAlive);
      if (client) {
        await client.query("SELECT pg_advisory_unlock($1)", [LOCK_KEY]).catch(() => {});
        await client.end().catch(() => {});
      }
      leader = false;
    },
  };
}
