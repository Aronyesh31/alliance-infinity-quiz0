import http from "node:http";
import { Server } from "socket.io";
import { z } from "zod";
import { verifyInternal, verifyTicket, INTERNAL_SIG_HEADER, INTERNAL_TS_HEADER } from "@/lib/realtime/ticket";
import type { ClientToServerEvents, InternalNotification, ServerToClientEvents } from "@/lib/realtime/protocol";
import { SOCKET_ERRORS } from "@/lib/realtime/protocol";
import { envInt } from "@/lib/config";
import { Registry, rooms, type AppSocket, type IO, type SocketData } from "./engine";
import * as repo from "./repo";
import { log } from "./log";

export interface RealtimeOptions {
  port: number;
  secret: string;
  allowedOrigins: string[];
  isLeader: () => boolean;
}

export interface RealtimeServer {
  httpServer: http.Server;
  io: IO;
  registry: Registry;
  listen: () => Promise<number>;
  onLeadershipAcquired: () => Promise<void>;
  close: () => Promise<void>;
}

const idSchema = z.string().min(10).max(40).regex(/^[a-z0-9]+$/);
const answerSchema = z.object({ questionIndex: z.int().min(0).max(1000), choiceIndex: z.int().min(0).max(9) });
const commandSchema = z.discriminatedUnion("type", [
  z.object({ type: z.literal("start") }),
  z.object({ type: z.literal("pause") }),
  z.object({ type: z.literal("resume") }),
  z.object({ type: z.literal("endQuestion") }),
  z.object({ type: z.literal("endGame") }),
  z.object({ type: z.literal("setRegistration"), open: z.boolean() }),
  z.object({ type: z.literal("removeTeam"), teamId: idSchema }),
]);

/** Small per-socket token bucket so one client cannot flood the server. */
function makeBucket(capacity: number, refillPerSec: number) {
  let tokens = capacity;
  let last = Date.now();
  return () => {
    const now = Date.now();
    tokens = Math.min(capacity, tokens + ((now - last) / 1000) * refillPerSec);
    last = now;
    if (tokens < 1) return false;
    tokens -= 1;
    return true;
  };
}

export function createRealtimeServer(opts: RealtimeOptions): RealtimeServer {
  const startedAt = Date.now();
  const maxConnections = envInt("REALTIME_MAX_CONNECTIONS", 5000);

  const httpServer = http.createServer((req, res) => {
    void handleHttp(req, res);
  });

  const io: IO = new Server<ClientToServerEvents, ServerToClientEvents, Record<string, never>, SocketData>(httpServer, {
    cors: { origin: opts.allowedOrigins, methods: ["GET", "POST"], credentials: false },
    pingInterval: 10_000,
    pingTimeout: 20_000,
    maxHttpBufferSize: 16 * 1024,
    connectTimeout: 20_000,
    allowRequest: (_req, callback) => callback(null, io.engine.clientsCount < maxConnections),
  });

  const registry = new Registry(io, { leader: opts.isLeader, startedAt });

  // ─── Handshake authentication ───
  io.use(async (socket, next) => {
    try {
      if (!opts.isLeader()) return next(new Error(SOCKET_ERRORS.notReady));
      const auth = (socket.handshake.auth ?? {}) as Record<string, unknown>;

      if (auth.role === "screen") {
        const sessionId = idSchema.safeParse(auth.sessionId);
        if (!sessionId.success) return next(new Error(SOCKET_ERRORS.sessionMissing));
        socket.data = { role: "screen", sessionId: sessionId.data };
        return next();
      }

      const ticket = verifyTicket(auth.ticket, opts.secret);
      if (!ticket) return next(new Error(SOCKET_ERRORS.unauthorized));

      if (ticket.role === "team") {
        const rt = await registry.get(ticket.sessionId);
        if (!rt) return next(new Error(SOCKET_ERRORS.sessionMissing));
        const team = await rt.ensureTeam(ticket.teamId);
        if (!team) return next(new Error(SOCKET_ERRORS.removed));
        socket.data = { role: "team", teamId: ticket.teamId, sessionId: ticket.sessionId };
        return next();
      }

      if (!(await repo.isAdminSessionValid(ticket.adminSessionId))) return next(new Error(SOCKET_ERRORS.unauthorized));
      socket.data = { role: "admin", adminSessionId: ticket.adminSessionId, watching: null };
      return next();
    } catch (error) {
      log.error("handshake failed", { error: String(error) });
      return next(new Error(SOCKET_ERRORS.notReady));
    }
  });

  io.on("connection", (socket: AppSocket) => {
    void onConnection(socket);
  });

  async function onConnection(socket: AppSocket) {
    const syncBucket = makeBucket(12, 2);
    socket.on("time:sync", (_clientSentAt, ack) => {
      if (typeof ack !== "function" || !syncBucket()) return;
      ack(Date.now());
    });

    const data = socket.data;

    if (data.role === "screen") {
      const rt = await registry.get(data.sessionId);
      if (!rt) {
        socket.disconnect(true);
        return;
      }
      rt.attachScreen(socket);
      return;
    }

    if (data.role === "team") {
      const rt = await registry.get(data.sessionId);
      const team = rt ? await rt.ensureTeam(data.teamId) : null;
      if (!rt || !team) {
        socket.emit("team:removed");
        socket.disconnect(true);
        return;
      }
      rt.attachTeam(socket, team);
      const answerBucket = makeBucket(6, 1);
      socket.on("answer:submit", async (payload, ack) => {
        if (typeof ack !== "function") return;
        if (!answerBucket()) return ack({ ok: false, code: "rate_limited", message: "Slow down — try again in a moment." });
        const parsed = answerSchema.safeParse(payload);
        if (!parsed.success) return ack({ ok: false, code: "invalid", message: "Invalid answer." });
        try {
          ack(await rt.submitAnswer(data.teamId, parsed.data.questionIndex, parsed.data.choiceIndex));
        } catch (error) {
          log.error("submit failed", { error: String(error) });
          ack({ ok: false, code: "server_error", message: "Something went wrong. Try again." });
        }
      });
      socket.on("disconnect", () => rt.detachTeam(socket.id, data.teamId));
      return;
    }

    // Admin
    const adminBucket = makeBucket(20, 5);
    socket.on("admin:watch", async (payload, ack) => {
      if (typeof ack !== "function") return;
      if (!adminBucket()) return ack({ ok: false, code: "rate_limited", message: "Too many requests." });
      const sessionId = idSchema.safeParse(payload?.sessionId);
      if (!sessionId.success) return ack({ ok: false, code: "invalid", message: "Invalid session." });
      if (socket.data.role !== "admin" || !(await repo.isAdminSessionValid(socket.data.adminSessionId))) {
        ack({ ok: false, code: "unauthorized", message: "Your admin session has expired. Sign in again." });
        socket.disconnect(true);
        return;
      }
      const rt = await registry.get(sessionId.data);
      if (!rt) return ack({ ok: false, code: "not_found", message: "Game not found." });
      const previous = socket.data.watching;
      if (previous && previous !== rt.id) {
        void socket.leave(rooms.pub(previous));
        void socket.leave(rooms.screen(previous));
        void socket.leave(rooms.admin(previous));
      }
      socket.data.watching = rt.id;
      rt.attachAdmin(socket);
      ack({ ok: true });
    });

    socket.on("admin:command", async (payload, ack) => {
      if (typeof ack !== "function") return;
      if (!adminBucket()) return ack({ ok: false, code: "rate_limited", message: "Too many requests." });
      const sessionId = idSchema.safeParse(payload?.sessionId);
      const command = commandSchema.safeParse(payload?.command);
      if (!sessionId.success || !command.success) return ack({ ok: false, code: "invalid", message: "Invalid command." });
      if (socket.data.role !== "admin" || !(await repo.isAdminSessionValid(socket.data.adminSessionId))) {
        ack({ ok: false, code: "unauthorized", message: "Your admin session has expired. Sign in again." });
        socket.disconnect(true);
        return;
      }
      const rt = await registry.get(sessionId.data);
      if (!rt) return ack({ ok: false, code: "not_found", message: "Game not found." });
      try {
        ack(await rt.command(command.data));
      } catch (error) {
        log.error("admin command failed", { error: String(error), command: command.data.type });
        ack({ ok: false, code: "server_error", message: "The command failed. Check the server logs." });
      }
    });
  }

  // ─── Plain HTTP: health check and signed notifications from the web app ───
  async function handleHttp(req: http.IncomingMessage, res: http.ServerResponse) {
    const url = new URL(req.url ?? "/", "http://localhost");
    if (req.method === "GET" && (url.pathname === "/healthz" || url.pathname === "/")) {
      res.writeHead(200, { "content-type": "application/json", "cache-control": "no-store" });
      res.end(
        JSON.stringify({
          ok: true,
          service: "aic-realtime",
          leader: opts.isLeader(),
          uptimeSec: Math.round((Date.now() - startedAt) / 1000),
          sockets: io.engine.clientsCount,
          liveSessions: registry.all().length,
        }),
      );
      return;
    }
    if (req.method === "POST" && url.pathname === "/internal/notify") {
      const body = await readBody(req, 10_000).catch(() => null);
      const ts = req.headers[INTERNAL_TS_HEADER] as string | undefined;
      const sig = req.headers[INTERNAL_SIG_HEADER] as string | undefined;
      if (body === null || !verifyInternal(body, ts, sig, opts.secret)) {
        res.writeHead(401).end();
        return;
      }
      try {
        await handleNotification(JSON.parse(body) as InternalNotification);
        res.writeHead(204).end();
      } catch (error) {
        log.error("notification failed", { error: String(error) });
        res.writeHead(500).end();
      }
      return;
    }
    res.writeHead(404, { "content-type": "text/plain" }).end("Not found");
  }

  async function handleNotification(n: InternalNotification) {
    switch (n.type) {
      case "team.joined": {
        const rt = registry.peek(n.sessionId);
        if (rt && idSchema.safeParse(n.teamId).success) {
          await rt.ensureTeam(n.teamId);
          rt.notifyTeamJoined();
        }
        return;
      }
      case "session.updated":
        await registry.peek(n.sessionId)?.reloadSettings();
        return;
      case "session.deleted":
        io.in(rooms.pub(n.sessionId)).disconnectSockets(true);
        registry.drop(n.sessionId);
        return;
      case "admin.loggedOut":
        for (const s of io.sockets.sockets.values()) {
          if (s.data.role === "admin" && s.data.adminSessionId === n.adminSessionId) s.disconnect(true);
        }
        return;
    }
  }

  // Periodically drop admin sockets whose session expired or was revoked.
  const adminSweep = setInterval(async () => {
    const checked = new Map<string, boolean>();
    for (const s of io.sockets.sockets.values()) {
      if (s.data.role !== "admin") continue;
      const id = s.data.adminSessionId;
      if (!checked.has(id)) checked.set(id, await repo.isAdminSessionValid(id).catch(() => true));
      if (!checked.get(id)) s.disconnect(true);
    }
  }, 60_000);

  return {
    httpServer,
    io,
    registry,
    listen: () =>
      new Promise((resolve) => {
        httpServer.listen(opts.port, () => {
          const addr = httpServer.address();
          resolve(typeof addr === "object" && addr ? addr.port : opts.port);
        });
      }),
    onLeadershipAcquired: async () => {
      const recovered = await registry.recoverActive();
      registry.startWatchdog();
      log.info("realtime ready", { recoveredSessions: recovered });
    },
    close: async () => {
      clearInterval(adminSweep);
      registry.stop();
      io.disconnectSockets(true);
      await new Promise<void>((resolve) => io.close(() => resolve()));
    },
  };
}

function readBody(req: http.IncomingMessage, limit: number): Promise<string> {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks: Buffer[] = [];
    req.on("data", (chunk: Buffer) => {
      size += chunk.length;
      if (size > limit) {
        reject(new Error("too large"));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on("end", () => resolve(Buffer.concat(chunks).toString("utf8")));
    req.on("error", reject);
  });
}
