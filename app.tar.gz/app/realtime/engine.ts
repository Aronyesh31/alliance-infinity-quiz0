// Server-authoritative game engine. One SessionRuntime per live game.
//
// Timing model
//   • On opening a question the server fixes startedAt and deadline
//     (startedAt + timeLimit), persists both, then broadcasts them.
//   • Clients render a countdown against the server clock (they estimate the
//     offset with time:sync) but never decide anything themselves.
//   • An answer is accepted only if the server receives it while the question
//     is open and at or before the deadline (plus ANSWER_GRACE_MS, default 0).
//   • A timer fires at the deadline: answers stop, in-flight writes finish,
//     results are revealed, and after revealSeconds the next question opens
//     automatically. No admin action is needed between questions.
//   • State transitions are serialised through a per-session mutex, and every
//     transition is persisted so a restarted server resumes on schedule.

import type { Server, Socket } from "socket.io";
import { computePoints } from "@/lib/game/scoring";
import { rankTeams, type RankedTeam } from "@/lib/game/ranking";
import { PUBLIC_LEADERBOARD_SIZE, envInt } from "@/lib/config";
import type {
  Ack,
  AdminCommand,
  AdminEvent,
  AdminSnapshot,
  ClientToServerEvents,
  GameState,
  LeaderboardEntry,
  PublicQuestion,
  PublicSnapshot,
  RevealInfo,
  ServerToClientEvents,
  TeamSelf,
} from "@/lib/realtime/protocol";
import * as repo from "./repo";
import { log } from "./log";

export type IO = Server<ClientToServerEvents, ServerToClientEvents, Record<string, never>, SocketData>;
export type AppSocket = Socket<ClientToServerEvents, ServerToClientEvents, Record<string, never>, SocketData>;

export type SocketData =
  | { role: "team"; teamId: string; sessionId: string }
  | { role: "admin"; adminSessionId: string; watching: string | null }
  | { role: "screen"; sessionId: string };

interface RuntimeQuestion {
  id: string;
  index: number;
  type: "MULTIPLE_CHOICE" | "TRUE_FALSE";
  text: string;
  choices: string[];
  correctIndex: number;
  imageId: string | null;
  timeLimitSec: number;
  points: number;
  explanation: string;
}

interface RuntimeTeam {
  id: string;
  name: string;
  score: number;
  correctCount: number;
  answeredCount: number;
  correctTimeMs: number;
  joinedAt: number;
  removed: boolean;
  sockets: Set<string>;
}

interface RecordedAnswer {
  choiceIndex: number;
  isCorrect: boolean;
  points: number;
  responseMs: number;
}

interface TeamResult {
  questionIndex: number;
  isCorrect: boolean;
  points: number;
  answered: boolean;
}

const ok = { ok: true as const };
const fail = (code: string, message: string) => ({ ok: false as const, code, message });

export const rooms = {
  pub: (sessionId: string) => `pub:${sessionId}`,
  screen: (sessionId: string) => `screen:${sessionId}`,
  admin: (sessionId: string) => `admin:${sessionId}`,
  team: (teamId: string) => `team:${teamId}`,
};

/** Runs at most once per `ms`, always with the latest state (trailing edge). */
class Throttle {
  private timer: NodeJS.Timeout | null = null;
  constructor(private readonly ms: number, private readonly fn: () => void) {}
  schedule() {
    if (this.timer) return;
    this.timer = setTimeout(() => {
      this.timer = null;
      this.fn();
    }, this.ms);
  }
  cancel() {
    if (this.timer) clearTimeout(this.timer);
    this.timer = null;
  }
}

export interface RuntimeStats {
  leader: () => boolean;
  startedAt: number;
}

export class SessionRuntime {
  readonly id: string;
  title = "";
  pin = "";
  scoringMode: "SPEED" | "ACCURACY" = "SPEED";
  state: GameState = "LOBBY";
  pausedFrom: GameState | null = null;
  registrationOpen = false;
  capacity = 500;
  revealSeconds = 5;
  showTeamStanding = true;
  showAnswerFeedback = true;
  allowLateJoin = false;

  currentIndex = -1;
  questionStartedAt: number | null = null;
  deadline: number | null = null;
  revealEndsAt: number | null = null;
  pausedRemainingMs: number | null = null;
  pausedAt: number | null = null;

  questions: RuntimeQuestion[] = [];
  teams = new Map<string, RuntimeTeam>();

  /** Answers to the current question, keyed by team id. */
  private answers = new Map<string, RecordedAnswer>();
  private distribution: number[] = [];
  private accepting = false;
  private inflight = new Set<Promise<unknown>>();
  private timer: NodeJS.Timeout | null = null;
  private chain: Promise<unknown> = Promise.resolve();

  private lastReveal: RevealInfo | null = null;
  private lastResults = new Map<string, TeamResult>();
  private standings = new Map<string, { rank: number; score: number; correctCount: number }>();
  private leaderboard: LeaderboardEntry[] | null = null;

  private events: AdminEvent[] = [];
  lastDbWriteMs: number | null = null;
  failedWrites = 0;
  disposed = false;

  private readonly progressThrottle: Throttle;
  private readonly lobbyThrottle: Throttle;
  private readonly adminThrottle: Throttle;
  /** Lobby-only changes (team count) are batched so joins don't flood every phone. */
  private readonly stateThrottle: Throttle;
  private readonly graceMs = envInt("ANSWER_GRACE_MS", 0);

  constructor(id: string, private readonly io: IO, private readonly stats: RuntimeStats) {
    this.id = id;
    this.progressThrottle = new Throttle(250, () => this.emitProgress());
    this.lobbyThrottle = new Throttle(500, () => this.emitLobby());
    this.adminThrottle = new Throttle(400, () => this.emitAdmin());
    this.stateThrottle = new Throttle(1500, () => this.broadcastState());
  }

  // ───────────────────────────── Loading & recovery ─────────────────────────────

  static async load(id: string, io: IO, stats: RuntimeStats): Promise<SessionRuntime | null> {
    const session = await repo.loadSession(id);
    if (!session) return null;
    const rt = new SessionRuntime(id, io, stats);
    rt.title = session.title;
    rt.pin = session.pin;
    rt.scoringMode = session.scoringMode;
    rt.state = session.state;
    rt.pausedFrom = session.pausedFromState;
    rt.registrationOpen = session.registrationOpen;
    rt.capacity = session.capacity;
    rt.revealSeconds = session.revealSeconds;
    rt.showTeamStanding = session.showTeamStanding;
    rt.showAnswerFeedback = session.showAnswerFeedback;
    rt.allowLateJoin = session.allowLateJoin;
    rt.currentIndex = session.currentQuestionIndex;
    rt.questionStartedAt = session.questionStartedAt?.getTime() ?? null;
    rt.deadline = session.questionDeadline?.getTime() ?? null;
    rt.revealEndsAt = session.revealEndsAt?.getTime() ?? null;
    rt.pausedRemainingMs = session.pausedRemainingMs;
    rt.pausedAt = session.pausedAt?.getTime() ?? null;
    rt.questions = session.questions.map((q) => ({
      id: q.id,
      index: q.position,
      type: q.type,
      text: q.text,
      choices: q.choices,
      correctIndex: q.correctIndex,
      imageId: q.imageId,
      timeLimitSec: q.timeLimitSec,
      points: q.points,
      explanation: q.explanation,
    }));

    for (const t of await repo.loadTeams(id)) {
      rt.teams.set(t.id, {
        id: t.id,
        name: t.name,
        score: t.score,
        correctCount: t.correctCount,
        answeredCount: t.answeredCount,
        correctTimeMs: t.correctTimeMs,
        joinedAt: t.joinedAt.getTime(),
        removed: t.removedAt !== null,
        sockets: new Set(),
      });
    }

    const recent = await repo.loadRecentEvents(id);
    rt.events = recent.reverse().map((e) => ({
      at: e.createdAt.getTime(),
      level: (["info", "warn", "error"].includes(e.level) ? e.level : "info") as AdminEvent["level"],
      message: e.message,
    }));

    // Rebuild the current question's answers so duplicates stay blocked and the
    // reveal can be recomputed after a restart.
    if (rt.currentIndex >= 0 && rt.state !== "LOBBY") {
      rt.resetQuestionState();
      for (const a of await repo.loadAnswersForQuestion(id, rt.currentIndex)) {
        if (!rt.teams.has(a.teamId)) continue;
        rt.answers.set(a.teamId, a);
        if (a.choiceIndex >= 0 && a.choiceIndex < rt.distribution.length) rt.distribution[a.choiceIndex]++;
      }
      if (rt.state === "REVEAL" || (rt.state === "PAUSED" && rt.pausedFrom === "REVEAL") || rt.state === "FINISHED") {
        rt.computeReveal();
      }
    }
    if (rt.state === "FINISHED") rt.computeStandings();
    return rt;
  }

  /** Re-arms timers for a game that was live when the server stopped. */
  async recover(): Promise<void> {
    const now = Date.now();
    if (this.state === "QUESTION" && this.deadline !== null) {
      this.accepting = now <= this.deadline;
      this.log("warn", `Realtime server restarted mid-question ${this.currentIndex + 1}; deadline unchanged.`);
      this.schedule(this.deadline, () => void this.closeQuestion(this.currentIndex));
    } else if (this.state === "REVEAL" && this.revealEndsAt !== null) {
      this.log("warn", "Realtime server restarted during results; continuing automatically.");
      const index = this.currentIndex;
      this.schedule(this.revealEndsAt, () => void this.advance(index));
    } else if (this.state === "PAUSED") {
      this.log("warn", "Realtime server restarted while paused. Resume when ready.");
    }
    this.broadcastState();
  }

  async reloadSettings(): Promise<void> {
    const s = await repo.loadSessionSettings(this.id);
    if (!s) return;
    this.capacity = s.capacity;
    this.revealSeconds = s.revealSeconds;
    this.showTeamStanding = s.showTeamStanding;
    this.showAnswerFeedback = s.showAnswerFeedback;
    this.allowLateJoin = s.allowLateJoin;
    this.registrationOpen = s.registrationOpen;
    this.broadcastState();
    this.adminThrottle.schedule();
  }

  /** Loads a team that joined after this runtime was created. */
  async ensureTeam(teamId: string): Promise<RuntimeTeam | null> {
    const existing = this.teams.get(teamId);
    if (existing) return existing.removed ? null : existing;
    const t = await repo.loadTeam(this.id, teamId);
    if (!t) return null;
    const team: RuntimeTeam = {
      id: t.id,
      name: t.name,
      score: t.score,
      correctCount: t.correctCount,
      answeredCount: t.answeredCount,
      correctTimeMs: t.correctTimeMs,
      joinedAt: t.joinedAt.getTime(),
      removed: t.removedAt !== null,
      sockets: new Set(),
    };
    this.teams.set(team.id, team);
    if (!team.removed) {
      this.lobbyThrottle.schedule();
      this.adminThrottle.schedule();
    }
    return team.removed ? null : team;
  }

  // ───────────────────────────── Sockets ─────────────────────────────

  attachTeam(socket: AppSocket, team: RuntimeTeam): void {
    // One active device per team: a newer connection replaces older ones.
    for (const oldId of team.sockets) {
      const old = this.io.sockets.sockets.get(oldId);
      if (old && old.id !== socket.id) {
        old.emit("team:superseded");
        old.disconnect(true);
      }
    }
    team.sockets.clear();
    team.sockets.add(socket.id);
    void socket.join([rooms.pub(this.id), rooms.team(team.id)]);
    socket.emit("state", this.publicSnapshot());
    socket.emit("team:self", this.teamSelf(team.id));
    this.adminThrottle.schedule();
  }

  detachTeam(socketId: string, teamId: string): void {
    const team = this.teams.get(teamId);
    if (!team) return;
    team.sockets.delete(socketId);
    this.adminThrottle.schedule();
  }

  attachScreen(socket: AppSocket): void {
    void socket.join([rooms.pub(this.id), rooms.screen(this.id)]);
    socket.emit("state", this.publicSnapshot());
    socket.emit("lobby", this.lobbyUpdate());
  }

  attachAdmin(socket: AppSocket): void {
    void socket.join([rooms.pub(this.id), rooms.screen(this.id), rooms.admin(this.id)]);
    socket.emit("state", this.publicSnapshot());
    socket.emit("lobby", this.lobbyUpdate());
    socket.emit("admin:snapshot", this.adminSnapshot());
  }

  // ───────────────────────────── Answers ─────────────────────────────

  async submitAnswer(teamId: string, questionIndex: number, choiceIndex: number): Promise<Ack<{ choiceIndex: number; duplicate?: boolean }>> {
    const receivedAt = Date.now();
    if (this.state !== "QUESTION" || !this.accepting || this.deadline === null || this.questionStartedAt === null) {
      return fail("closed", this.state === "PAUSED" ? "The game is paused." : "This question is closed.");
    }
    if (questionIndex !== this.currentIndex) return fail("wrong_question", "That question is no longer open.");
    if (receivedAt > this.deadline + this.graceMs) return fail("too_late", "Time's up — the answer arrived after the deadline.");

    const team = this.teams.get(teamId);
    if (!team || team.removed) return fail("removed", "This team is not part of the game.");

    const question = this.questions[this.currentIndex];
    if (!Number.isInteger(choiceIndex) || choiceIndex < 0 || choiceIndex >= question.choices.length) {
      return fail("invalid_choice", "That answer choice does not exist.");
    }

    const existing = this.answers.get(teamId);
    if (existing) return { ok: true, choiceIndex: existing.choiceIndex, duplicate: true };

    const responseMs = Math.max(0, Math.min(receivedAt - this.questionStartedAt, question.timeLimitSec * 1000));
    const isCorrect = choiceIndex === question.correctIndex;
    const points = computePoints({
      isCorrect,
      maxPoints: question.points,
      responseMs,
      timeLimitMs: question.timeLimitSec * 1000,
      mode: this.scoringMode,
    });
    const record: RecordedAnswer = { choiceIndex, isCorrect, points, responseMs };

    // Claim the slot synchronously so a second submit cannot slip in.
    this.answers.set(teamId, record);
    this.distribution[choiceIndex]++;

    const write = (async () => {
      const t0 = Date.now();
      const outcome = await repo.insertAnswer({
        sessionId: this.id,
        teamId,
        sessionQuestionId: question.id,
        questionIndex: this.currentIndex,
        choiceIndex,
        isCorrect,
        points,
        responseMs,
        receivedAt: new Date(receivedAt),
      });
      this.lastDbWriteMs = Date.now() - t0;
      return outcome;
    })();
    this.inflight.add(write);
    try {
      const outcome = await write;
      if (outcome === "duplicate") {
        // Already stored (e.g. by a request handled before a restart).
        const stored = await repo.findAnswer(teamId, question.id);
        this.distribution[choiceIndex]--;
        if (stored) {
          this.answers.set(teamId, stored);
          this.distribution[stored.choiceIndex]++;
          return { ok: true, choiceIndex: stored.choiceIndex, duplicate: true };
        }
        this.answers.delete(teamId);
        return fail("save_failed", "Your answer could not be saved. Try again.");
      }
      team.score += points;
      team.answeredCount += 1;
      if (isCorrect) {
        team.correctCount += 1;
        team.correctTimeMs += responseMs;
      }
    } catch (error) {
      this.answers.delete(teamId);
      this.distribution[choiceIndex]--;
      this.failedWrites++;
      log.error("answer write failed", { sessionId: this.id, teamId, error: String(error) });
      return fail("save_failed", "Your answer could not be saved. Try again.");
    } finally {
      this.inflight.delete(write);
    }

    this.progressThrottle.schedule();
    this.adminThrottle.schedule();
    return { ok: true, choiceIndex };
  }

  // ───────────────────────────── Admin commands ─────────────────────────────

  async command(cmd: AdminCommand): Promise<Ack> {
    switch (cmd.type) {
      case "start":
        return this.start();
      case "pause":
        return this.pause();
      case "resume":
        return this.resume();
      case "endQuestion":
        return this.endQuestionEarly();
      case "endGame":
        return this.endGame();
      case "setRegistration":
        return this.setRegistration(cmd.open);
      case "removeTeam":
        return this.removeTeam(cmd.teamId);
    }
  }

  start(): Promise<Ack> {
    return this.exclusive(async () => {
      if (this.state !== "LOBBY") return fail("bad_state", "The game has already started.");
      if (this.questions.length === 0) return fail("no_questions", "This game has no questions.");
      if (this.activeTeamCount() === 0) return fail("no_teams", "At least one team must join before starting.");
      if (!this.allowLateJoin) this.registrationOpen = false;
      await this.persist({ startedAt: new Date(), registrationOpen: this.registrationOpen });
      this.log("info", `Game started with ${this.activeTeamCount()} teams.`);
      await this.openQuestionLocked(0);
      return ok;
    });
  }

  pause(): Promise<Ack> {
    return this.exclusive(async () => {
      if (this.state !== "QUESTION" && this.state !== "REVEAL") return fail("bad_state", "Only a running question or results screen can be paused.");
      const now = Date.now();
      const from = this.state;
      if (from === "QUESTION") {
        this.accepting = false;
        await this.drainInflight();
      }
      this.clearTimer();
      const endsAt = from === "QUESTION" ? this.deadline! : this.revealEndsAt!;
      this.pausedFrom = from;
      this.pausedRemainingMs = Math.max(0, endsAt - now);
      this.pausedAt = now;
      this.state = "PAUSED";
      await this.persist({
        state: "PAUSED",
        pausedFromState: from,
        pausedRemainingMs: this.pausedRemainingMs,
        pausedAt: new Date(now),
      });
      this.log("warn", `Game paused with ${Math.ceil(this.pausedRemainingMs / 1000)}s remaining.`);
      this.broadcastState();
      this.emitTeamSelfAll();
      return ok;
    });
  }

  resume(): Promise<Ack> {
    return this.exclusive(async () => {
      if (this.state !== "PAUSED" || !this.pausedFrom) return fail("bad_state", "The game is not paused.");
      const now = Date.now();
      const remaining = this.pausedRemainingMs ?? 0;
      const pausedFor = this.pausedAt ? now - this.pausedAt : 0;
      const from = this.pausedFrom;
      this.pausedFrom = null;
      this.pausedRemainingMs = null;
      this.pausedAt = null;
      if (from === "QUESTION") {
        // Shift the whole window so elapsed time (and speed points) exclude the pause.
        this.questionStartedAt = (this.questionStartedAt ?? now) + pausedFor;
        this.deadline = now + remaining;
        this.state = "QUESTION";
        await this.persist({
          state: "QUESTION",
          questionStartedAt: new Date(this.questionStartedAt),
          questionDeadline: new Date(this.deadline),
          pausedFromState: null,
          pausedRemainingMs: null,
          pausedAt: null,
        });
        this.accepting = true;
        const index = this.currentIndex;
        this.schedule(this.deadline, () => void this.closeQuestion(index));
      } else {
        this.revealEndsAt = now + remaining;
        this.state = "REVEAL";
        await this.persist({
          state: "REVEAL",
          revealEndsAt: new Date(this.revealEndsAt),
          pausedFromState: null,
          pausedRemainingMs: null,
          pausedAt: null,
        });
        const index = this.currentIndex;
        this.schedule(this.revealEndsAt, () => void this.advance(index));
      }
      this.log("info", "Game resumed.");
      this.broadcastState();
      this.emitTeamSelfAll();
      return ok;
    });
  }

  endQuestionEarly(): Promise<Ack> {
    return this.exclusive(async () => {
      if (this.state !== "QUESTION") return fail("bad_state", "No question is open.");
      this.log("warn", `Question ${this.currentIndex + 1} ended early by the admin.`);
      await this.closeQuestionLocked(this.currentIndex);
      return ok;
    });
  }

  endGame(): Promise<Ack> {
    return this.exclusive(async () => {
      if (this.state === "FINISHED") return fail("bad_state", "The game has already ended.");
      if (this.state === "QUESTION") {
        this.accepting = false;
        await this.drainInflight();
      }
      this.clearTimer();
      this.log("warn", "Game ended by the admin.");
      await this.finishLocked();
      return ok;
    });
  }

  setRegistration(open: boolean): Promise<Ack> {
    return this.exclusive(async () => {
      if (this.state === "FINISHED") return fail("bad_state", "The game has ended.");
      if (open && this.state !== "LOBBY" && !this.allowLateJoin) {
        return fail("late_join_off", "Late joining is turned off for this game.");
      }
      this.registrationOpen = open;
      await this.persist({ registrationOpen: open });
      this.log("info", open ? "Registration opened." : "Registration closed.");
      this.broadcastState();
      this.adminThrottle.schedule();
      return ok;
    });
  }

  async removeTeam(teamId: string): Promise<Ack> {
    const team = this.teams.get(teamId);
    if (!team || team.removed) return fail("not_found", "That team is not in this game.");
    const removed = await repo.removeTeam(this.id, teamId);
    if (!removed) return fail("not_found", "That team was already removed.");
    team.removed = true;
    this.io.to(rooms.team(teamId)).emit("team:removed");
    this.io.in(rooms.team(teamId)).disconnectSockets(true);
    team.sockets.clear();
    this.log("warn", `Team "${team.name}" removed.`);
    if (this.state === "REVEAL" || this.state === "FINISHED" || (this.state === "PAUSED" && this.pausedFrom === "REVEAL")) {
      this.computeStandings();
      if (this.state === "FINISHED") await this.persistFinalRanks();
      this.broadcastState();
      this.emitTeamSelfAll();
    } else {
      this.broadcastState();
    }
    this.lobbyThrottle.schedule();
    this.adminThrottle.schedule();
    return ok;
  }

  // ───────────────────────────── Transitions (mutex held) ─────────────────────────────

  closeQuestion(index: number): Promise<void> {
    return this.exclusive(() => this.closeQuestionLocked(index));
  }

  advance(fromIndex: number): Promise<void> {
    return this.exclusive(async () => {
      if (this.state !== "REVEAL" || this.currentIndex !== fromIndex) return;
      if (fromIndex + 1 < this.questions.length) await this.openQuestionLocked(fromIndex + 1);
      else await this.finishLocked();
    });
  }

  private async openQuestionLocked(index: number): Promise<void> {
    const question = this.questions[index];
    const startedAt = Date.now();
    const deadline = startedAt + question.timeLimitSec * 1000;
    this.currentIndex = index;
    this.resetQuestionState();
    this.questionStartedAt = startedAt;
    this.deadline = deadline;
    this.revealEndsAt = null;
    this.lastReveal = null;
    this.lastResults.clear();
    this.state = "QUESTION";
    await this.persist({
      state: "QUESTION",
      currentQuestionIndex: index,
      questionStartedAt: new Date(startedAt),
      questionDeadline: new Date(deadline),
      revealEndsAt: null,
    });
    this.accepting = true;
    this.schedule(deadline, () => void this.closeQuestion(index));
    this.log("info", `Question ${index + 1} of ${this.questions.length} opened.`);
    this.broadcastState();
    this.emitTeamSelfAll();
    this.adminThrottle.schedule();
  }

  private async closeQuestionLocked(index: number): Promise<void> {
    if (this.state !== "QUESTION" || this.currentIndex !== index) return;
    this.accepting = false;
    this.clearTimer();
    await this.drainInflight();
    const now = Date.now();
    this.revealEndsAt = now + this.revealSeconds * 1000;
    this.state = "REVEAL";
    this.computeReveal();
    this.computeStandings();
    await this.persist({ state: "REVEAL", revealEndsAt: new Date(this.revealEndsAt) });
    this.log("info", `Question ${index + 1} closed: ${this.answers.size} of ${this.activeTeamCount()} teams answered.`);
    this.broadcastState();
    this.emitTeamSelfAll();
    this.adminThrottle.schedule();
    this.schedule(this.revealEndsAt, () => void this.advance(index));
  }

  private async finishLocked(): Promise<void> {
    this.state = "FINISHED";
    this.accepting = false;
    this.registrationOpen = false;
    this.pausedFrom = null;
    this.pausedRemainingMs = null;
    this.pausedAt = null;
    this.clearTimer();
    if (this.currentIndex >= 0 && !this.lastReveal) this.computeReveal();
    this.computeStandings();
    await this.persist({
      state: "FINISHED",
      registrationOpen: false,
      endedAt: new Date(),
      pausedFromState: null,
      pausedRemainingMs: null,
      pausedAt: null,
    });
    await this.persistFinalRanks();
    this.log("info", "Game finished. Final rankings saved.");
    this.broadcastState();
    this.emitTeamSelfAll();
    this.adminThrottle.schedule();
  }

  /** Called every second by the registry as a safety net for lost timers. */
  watchdog(now = Date.now()): void {
    if (this.state === "QUESTION" && this.deadline !== null && now > this.deadline + 1000) {
      void this.closeQuestion(this.currentIndex);
    } else if (this.state === "REVEAL" && this.revealEndsAt !== null && now > this.revealEndsAt + 1000) {
      void this.advance(this.currentIndex);
    }
  }

  dispose(): void {
    this.disposed = true;
    this.clearTimer();
    this.progressThrottle.cancel();
    this.lobbyThrottle.cancel();
    this.adminThrottle.cancel();
    this.stateThrottle.cancel();
  }

  // ───────────────────────────── Derived data ─────────────────────────────

  private resetQuestionState() {
    this.answers = new Map();
    const q = this.questions[this.currentIndex];
    this.distribution = new Array(q ? q.choices.length : 0).fill(0);
  }

  private computeReveal() {
    const q = this.questions[this.currentIndex];
    if (!q) return;
    this.lastReveal = {
      questionIndex: q.index,
      correctIndex: q.correctIndex,
      distribution: [...this.distribution],
      answeredCount: this.answers.size,
      explanation: q.explanation,
    };
    this.lastResults.clear();
    for (const team of this.teams.values()) {
      if (team.removed) continue;
      const a = this.answers.get(team.id);
      this.lastResults.set(team.id, {
        questionIndex: q.index,
        isCorrect: a?.isCorrect ?? false,
        points: a?.points ?? 0,
        answered: !!a,
      });
    }
  }

  private ranked(): RankedTeam<RuntimeTeam>[] {
    return rankTeams([...this.teams.values()].filter((t) => !t.removed));
  }

  private computeStandings() {
    const ranked = this.ranked();
    this.standings.clear();
    for (const t of ranked) this.standings.set(t.id, { rank: t.rank, score: t.score, correctCount: t.correctCount });
    this.leaderboard = ranked.slice(0, PUBLIC_LEADERBOARD_SIZE).map((t) => ({
      rank: t.rank,
      name: t.name,
      score: t.score,
      correctCount: t.correctCount,
    }));
  }

  private async persistFinalRanks() {
    const ranked = this.ranked();
    try {
      await repo.saveFinalRanks(this.id, ranked.map((t) => ({ id: t.id, rank: t.rank })));
    } catch (error) {
      this.failedWrites++;
      this.log("error", `Could not save final ranks: ${String(error)}`);
    }
  }

  activeTeamCount(): number {
    let n = 0;
    for (const t of this.teams.values()) if (!t.removed) n++;
    return n;
  }

  connectedTeamCount(): number {
    let n = 0;
    for (const t of this.teams.values()) if (!t.removed && t.sockets.size > 0) n++;
    return n;
  }

  private publicQuestion(): PublicQuestion | null {
    const q = this.questions[this.currentIndex];
    if (!q || this.state === "LOBBY") return null;
    return {
      index: q.index,
      type: q.type,
      text: q.text,
      choices: q.choices,
      imageUrl: q.imageId ? `/api/images/${q.imageId}` : null,
      points: q.points,
      timeLimitSec: q.timeLimitSec,
    };
  }

  private revealVisible(): boolean {
    return this.state === "REVEAL" || this.state === "FINISHED" || (this.state === "PAUSED" && this.pausedFrom === "REVEAL");
  }

  publicSnapshot(): PublicSnapshot {
    return {
      sessionId: this.id,
      title: this.title,
      pin: this.pin,
      state: this.state,
      pausedFrom: this.pausedFrom,
      registrationOpen: this.registrationOpen,
      teamCount: this.activeTeamCount(),
      questionCount: this.questions.length,
      currentIndex: this.currentIndex,
      question: this.state === "FINISHED" ? null : this.publicQuestion(),
      questionStartedAt: this.questionStartedAt,
      deadline: this.deadline,
      revealEndsAt: this.revealEndsAt,
      pausedRemainingMs: this.pausedRemainingMs,
      answeredCount: this.answers.size,
      // The correct answer is only ever sent after the question has closed.
      reveal: this.revealVisible() ? this.lastReveal : null,
      leaderboard: this.revealVisible() ? this.leaderboard : null,
      showTeamStanding: this.showTeamStanding,
      showAnswerFeedback: this.showAnswerFeedback,
      serverNow: Date.now(),
    };
  }

  teamSelf(teamId: string): TeamSelf {
    const team = this.teams.get(teamId);
    const answer = this.answers.get(teamId);
    const inQuestion = this.state === "QUESTION" || (this.state === "PAUSED" && this.pausedFrom === "QUESTION") || this.revealVisible();
    const result = this.lastResults.get(teamId);
    const standing = this.standings.get(teamId);
    return {
      teamId,
      name: team?.name ?? "",
      answer: inQuestion && answer && this.state !== "FINISHED" ? { questionIndex: this.currentIndex, choiceIndex: answer.choiceIndex } : null,
      result: this.showAnswerFeedback && this.revealVisible() && result ? result : null,
      standing:
        this.showTeamStanding && standing
          ? { score: standing.score, rank: standing.rank, of: this.standings.size, correctCount: standing.correctCount }
          : null,
    };
  }

  private lobbyUpdate() {
    const active = [...this.teams.values()].filter((t) => !t.removed).sort((a, b) => b.joinedAt - a.joinedAt);
    return { teamCount: active.length, recentNames: active.slice(0, 80).map((t) => t.name) };
  }

  adminSnapshot(): AdminSnapshot {
    const ranked = this.ranked();
    const q = this.questions[this.currentIndex];
    return {
      sessionId: this.id,
      teams: ranked.map((t) => ({
        id: t.id,
        name: t.name,
        connected: t.sockets.size > 0,
        answeredCurrent: this.answers.has(t.id),
        score: t.score,
        correctCount: t.correctCount,
        rank: t.rank,
        joinedAt: t.joinedAt,
      })),
      connectedCount: this.connectedTeamCount(),
      answeredCount: this.answers.size,
      distribution: [...this.distribution],
      currentCorrectIndex: q && this.state !== "LOBBY" ? q.correctIndex : null,
      events: this.events.slice(-40),
      health: {
        leader: this.stats.leader(),
        uptimeSec: Math.round((Date.now() - this.stats.startedAt) / 1000),
        sockets: this.io.engine.clientsCount,
        lastDbWriteMs: this.lastDbWriteMs,
        failedWrites: this.failedWrites,
      },
    };
  }

  // ───────────────────────────── Emitters ─────────────────────────────

  broadcastState() {
    if (this.disposed) return;
    this.io.to(rooms.pub(this.id)).emit("state", this.publicSnapshot());
    this.lobbyThrottle.schedule();
  }

  private emitTeamSelfAll() {
    for (const team of this.teams.values()) {
      if (team.removed || team.sockets.size === 0) continue;
      this.io.to(rooms.team(team.id)).emit("team:self", this.teamSelf(team.id));
    }
  }

  private emitProgress() {
    if (this.disposed || this.state !== "QUESTION") return;
    this.io.to(rooms.pub(this.id)).emit("progress", { questionIndex: this.currentIndex, answeredCount: this.answers.size });
  }

  private emitLobby() {
    if (this.disposed) return;
    this.io.to(rooms.screen(this.id)).emit("lobby", this.lobbyUpdate());
  }

  private emitAdmin() {
    if (this.disposed) return;
    this.io.to(rooms.admin(this.id)).emit("admin:snapshot", this.adminSnapshot());
  }

  notifyTeamJoined() {
    this.stateThrottle.schedule();
    this.lobbyThrottle.schedule();
    this.adminThrottle.schedule();
  }

  // ───────────────────────────── Plumbing ─────────────────────────────

  private exclusive<T>(fn: () => Promise<T>): Promise<T> {
    const run = this.chain.then(fn, fn);
    this.chain = run.catch(() => undefined);
    return run;
  }

  private schedule(at: number, fn: () => void) {
    this.clearTimer();
    if (this.disposed) return;
    this.timer = setTimeout(() => {
      this.timer = null;
      fn();
    }, Math.max(0, at - Date.now()));
  }

  private clearTimer() {
    if (this.timer) clearTimeout(this.timer);
    this.timer = null;
  }

  private async drainInflight() {
    while (this.inflight.size > 0) await Promise.allSettled([...this.inflight]);
  }

  /**
   * Persists a transition. Retries briefly; if the database stays unavailable
   * the game keeps running on schedule from memory and the failure is surfaced
   * to the admin (timing takes priority over a perfect recovery point).
   */
  private async persist(data: Parameters<typeof repo.updateSession>[1]) {
    const delays = [0, 150, 500];
    for (let attempt = 0; attempt < delays.length; attempt++) {
      if (delays[attempt]) await new Promise((r) => setTimeout(r, delays[attempt]));
      try {
        const t0 = Date.now();
        await repo.updateSession(this.id, data);
        this.lastDbWriteMs = Date.now() - t0;
        return;
      } catch (error) {
        if (attempt === delays.length - 1) {
          this.failedWrites++;
          this.log("error", `Database write failed; continuing from memory. ${String(error).slice(0, 160)}`);
        }
      }
    }
  }

  log(level: AdminEvent["level"], message: string) {
    this.events.push({ at: Date.now(), level, message });
    if (this.events.length > 100) this.events.splice(0, this.events.length - 100);
    log[level === "error" ? "error" : level === "warn" ? "warn" : "info"](message, { sessionId: this.id });
    void repo.logEvent(this.id, level, message).catch(() => {});
    this.adminThrottle.schedule();
  }
}

/** Holds live runtimes and loads them on demand. */
export class Registry {
  private runtimes = new Map<string, SessionRuntime>();
  private loading = new Map<string, Promise<SessionRuntime | null>>();
  private watchdogTimer: NodeJS.Timeout | null = null;

  constructor(private readonly io: IO, private readonly stats: RuntimeStats) {}

  async get(sessionId: string): Promise<SessionRuntime | null> {
    const existing = this.runtimes.get(sessionId);
    if (existing) return existing;
    let pending = this.loading.get(sessionId);
    if (!pending) {
      pending = SessionRuntime.load(sessionId, this.io, this.stats)
        .then((rt) => {
          if (rt) this.runtimes.set(sessionId, rt);
          return rt;
        })
        .finally(() => this.loading.delete(sessionId));
      this.loading.set(sessionId, pending);
    }
    return pending;
  }

  peek(sessionId: string): SessionRuntime | undefined {
    return this.runtimes.get(sessionId);
  }

  drop(sessionId: string) {
    const rt = this.runtimes.get(sessionId);
    rt?.dispose();
    this.runtimes.delete(sessionId);
  }

  async recoverActive(): Promise<number> {
    const ids = await repo.findActiveSessionIds();
    for (const id of ids) {
      const rt = await this.get(id);
      await rt?.recover();
    }
    return ids.length;
  }

  startWatchdog() {
    this.watchdogTimer = setInterval(() => {
      const now = Date.now();
      for (const rt of this.runtimes.values()) rt.watchdog(now);
    }, 1000);
  }

  stop() {
    if (this.watchdogTimer) clearInterval(this.watchdogTimer);
    for (const rt of this.runtimes.values()) rt.dispose();
    this.runtimes.clear();
  }

  all(): SessionRuntime[] {
    return [...this.runtimes.values()];
  }
}
