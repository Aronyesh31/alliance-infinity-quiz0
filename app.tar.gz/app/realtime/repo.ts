// Database access for the realtime server. All live-game writes go through here.
import { prisma, isUniqueViolation, newId } from "@/lib/db";
import type { Prisma } from "@/generated/prisma/client";

export type SessionWithQuestions = Prisma.GameSessionGetPayload<{
  include: { questions: { orderBy: { position: "asc" } } };
}>;

export async function loadSession(sessionId: string): Promise<SessionWithQuestions | null> {
  return prisma.gameSession.findUnique({
    where: { id: sessionId },
    include: { questions: { orderBy: { position: "asc" } } },
  });
}

export async function loadSessionSettings(sessionId: string) {
  return prisma.gameSession.findUnique({
    where: { id: sessionId },
    select: {
      capacity: true,
      revealSeconds: true,
      showTeamStanding: true,
      showAnswerFeedback: true,
      allowLateJoin: true,
      registrationOpen: true,
      state: true,
    },
  });
}

export async function loadTeams(sessionId: string) {
  return prisma.team.findMany({
    where: { sessionId },
    select: {
      id: true,
      name: true,
      score: true,
      correctCount: true,
      answeredCount: true,
      correctTimeMs: true,
      joinedAt: true,
      removedAt: true,
    },
    orderBy: { joinedAt: "asc" },
  });
}

export async function loadTeam(sessionId: string, teamId: string) {
  return prisma.team.findFirst({
    where: { id: teamId, sessionId },
    select: {
      id: true,
      name: true,
      score: true,
      correctCount: true,
      answeredCount: true,
      correctTimeMs: true,
      joinedAt: true,
      removedAt: true,
    },
  });
}

export async function loadAnswersForQuestion(sessionId: string, questionIndex: number) {
  return prisma.answer.findMany({
    where: { sessionId, questionIndex },
    select: { teamId: true, choiceIndex: true, isCorrect: true, points: true, responseMs: true },
  });
}

export async function findAnswer(teamId: string, sessionQuestionId: string) {
  return prisma.answer.findUnique({
    where: { teamId_sessionQuestionId: { teamId, sessionQuestionId } },
    select: { choiceIndex: true, isCorrect: true, points: true, responseMs: true },
  });
}

export interface AnswerWrite {
  sessionId: string;
  teamId: string;
  sessionQuestionId: string;
  questionIndex: number;
  choiceIndex: number;
  isCorrect: boolean;
  points: number;
  responseMs: number;
  receivedAt: Date;
}

/**
 * Inserts the answer and updates the team's running totals in ONE statement
 * (atomic, one round trip). The unique (teamId, sessionQuestionId) index
 * guarantees one answer per team per question even if two requests race; a
 * duplicate aborts the whole statement, so the team totals never double-count.
 */
export async function insertAnswer(a: AnswerWrite): Promise<"inserted" | "duplicate"> {
  try {
    await prisma.$executeRaw`
      WITH ins AS (
        INSERT INTO "Answer" ("id", "sessionId", "teamId", "sessionQuestionId", "questionIndex", "choiceIndex", "isCorrect", "points", "responseMs", "receivedAt")
        VALUES (${newId()}, ${a.sessionId}, ${a.teamId}, ${a.sessionQuestionId}, ${a.questionIndex}, ${a.choiceIndex}, ${a.isCorrect}, ${a.points}, ${a.responseMs}, ${a.receivedAt})
        RETURNING "teamId"
      )
      UPDATE "Team" SET
        "score" = "score" + ${a.points},
        "answeredCount" = "answeredCount" + 1,
        "correctCount" = "correctCount" + ${a.isCorrect ? 1 : 0},
        "correctTimeMs" = "correctTimeMs" + ${a.isCorrect ? a.responseMs : 0}
      WHERE "id" = (SELECT "teamId" FROM ins)`;
    return "inserted";
  } catch (error) {
    if (isUniqueViolation(error)) return "duplicate";
    throw error;
  }
}

export async function updateSession(
  sessionId: string,
  data: Prisma.GameSessionUpdateManyMutationInput,
): Promise<number> {
  const result = await prisma.gameSession.updateMany({ where: { id: sessionId }, data });
  return result.count;
}

export async function removeTeam(sessionId: string, teamId: string): Promise<boolean> {
  return prisma.$transaction(async (tx) => {
    const updated = await tx.team.updateMany({
      where: { id: teamId, sessionId, removedAt: null },
      data: { removedAt: new Date() },
    });
    if (updated.count === 0) return false;
    await tx.gameSession.update({ where: { id: sessionId }, data: { teamCount: { decrement: 1 } } });
    return true;
  });
}

export async function saveFinalRanks(sessionId: string, ranks: { id: string; rank: number }[]): Promise<void> {
  const ids = ranks.map((r) => r.id);
  const values = ranks.map((r) => r.rank);
  await prisma.$transaction([
    prisma.team.updateMany({ where: { sessionId }, data: { finalRank: null } }),
    prisma.$executeRaw`
      UPDATE "Team" AS t SET "finalRank" = v.rank
      FROM unnest(${ids}::text[], ${values}::int[]) AS v(id, rank)
      WHERE t."id" = v.id AND t."sessionId" = ${sessionId}`,
  ]);
}

export async function logEvent(sessionId: string, level: string, message: string): Promise<void> {
  await prisma.gameEvent.create({ data: { sessionId, level, message: message.slice(0, 500) } });
}

export async function loadRecentEvents(sessionId: string, take = 40) {
  return prisma.gameEvent.findMany({
    where: { sessionId },
    orderBy: { createdAt: "desc" },
    take,
    select: { level: true, message: true, createdAt: true },
  });
}

export async function isAdminSessionValid(adminSessionId: string): Promise<boolean> {
  const row = await prisma.adminSession.findUnique({
    where: { id: adminSessionId },
    select: { expiresAt: true },
  });
  return !!row && row.expiresAt.getTime() > Date.now();
}

export async function findActiveSessionIds(): Promise<string[]> {
  const rows = await prisma.gameSession.findMany({
    where: { state: { in: ["QUESTION", "REVEAL", "PAUSED"] } },
    select: { id: true },
  });
  return rows.map((r) => r.id);
}
