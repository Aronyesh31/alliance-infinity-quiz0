// Structured one-line JSON logs (easy to read in Render/Railway/Fly log viewers).
type Fields = Record<string, unknown>;

function write(level: string, message: string, fields?: Fields) {
  if (process.env.REALTIME_LOG === "silent") return;
  const line = JSON.stringify({ t: new Date().toISOString(), level, msg: message, ...fields });
  if (level === "error" || level === "warn") console.error(line);
  else console.log(line);
}

export const log = {
  info: (m: string, f?: Fields) => write("info", m, f),
  warn: (m: string, f?: Fields) => write("warn", m, f),
  error: (m: string, f?: Fields) => write("error", m, f),
};
