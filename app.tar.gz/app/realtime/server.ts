// Entry point for the persistent Socket.IO realtime server.
// Deploy as a long-running Node process (Render, Railway, Fly.io…), never as a
// serverless function. Run exactly one instance; a Postgres advisory lock keeps
// a second instance (e.g. during a rolling deploy) on standby.
import "dotenv/config";
import { appOrigin, sharedSecret } from "@/lib/config";
import { prisma } from "@/lib/db";
import { createRealtimeServer } from "./app";
import { acquireLeaderLock } from "./leader";
import { log } from "./log";

async function main() {
  const secret = sharedSecret();
  const port = Number(process.env.PORT ?? 4000);
  const allowedOrigins = [appOrigin(), ...(process.env.REALTIME_EXTRA_ORIGINS ?? "").split(",")]
    .map((o) => o.trim().replace(/\/+$/, ""))
    .filter(Boolean);
  const lockUrl = process.env.DIRECT_URL || process.env.DATABASE_URL;
  if (!lockUrl) throw new Error("DATABASE_URL (and ideally DIRECT_URL) must be set.");

  let shuttingDown = false;
  const lock = acquireLeaderLock(lockUrl, () => {
    // Losing the lock means another instance may take over: stop immediately so
    // two servers never drive the same game. The platform restarts us.
    log.error("leadership lost; exiting so a single leader remains");
    process.exit(1);
  });

  const server = createRealtimeServer({ port, secret, allowedOrigins, isLeader: lock.isLeader });
  const boundPort = await server.listen();
  log.info("realtime listening", { port: boundPort, allowedOrigins });

  void lock.acquired.then(() => server.onLeadershipAcquired()).catch((error) => {
    log.error("startup recovery failed", { error: String(error) });
    process.exit(1);
  });

  const shutdown = async (signal: string) => {
    if (shuttingDown) return;
    shuttingDown = true;
    log.info("shutting down", { signal });
    // Game state is already persisted; the next leader resumes from the database.
    await server.close().catch(() => {});
    await lock.release().catch(() => {});
    await prisma.$disconnect().catch(() => {});
    process.exit(0);
  };
  process.on("SIGTERM", () => void shutdown("SIGTERM"));
  process.on("SIGINT", () => void shutdown("SIGINT"));
}

main().catch((error) => {
  log.error("fatal", { error: String(error) });
  process.exit(1);
});
