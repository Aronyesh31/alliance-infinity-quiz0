// Imports a quiz from a plain-text file (numbered questions, A)–D) options and an
// ANSWER KEY section) as a published quiz in standard event mode: 60 seconds and
// 1,000 points per question.
//
// Quiz files contain answers, so they live in the git-ignored private/ folder,
// never in the repository.
//
//   npm run seed:maths                                   → private/advanced-maths-quiz.txt
//   npm run seed:quiz -- private/round2.txt "Round 2"    → any file, any title
//   add --draft to create it as a draft instead
import "dotenv/config";
import fs from "node:fs";
import path from "node:path";
import { prisma } from "../src/lib/db";
import { parseTextQuiz } from "../src/lib/import/text-quiz";
import { normalizeQuiz, validateQuizForPublish, type QuizInput } from "../src/lib/validation/quiz";

const DEFAULT_FILE = "private/advanced-maths-quiz.txt";
const DEFAULT_TITLE = "Advanced College-Level Mathematics Quiz";

async function main() {
  const args = process.argv.slice(2).filter((a) => !a.startsWith("--"));
  const file = path.resolve(args[0] ?? DEFAULT_FILE);
  const draft = process.argv.includes("--draft");
  if (!fs.existsSync(file)) {
    console.error(`Quiz file not found: ${file}\nPut the quiz text in the private/ folder (it is git-ignored).`);
    process.exit(1);
  }
  const parsed = parseTextQuiz(fs.readFileSync(file, "utf8"));
  if (parsed.warnings.length) console.warn(parsed.warnings.join("\n"));
  const title = args[1] ?? (args[0] ? (parsed.title ?? path.basename(file, ".txt")) : DEFAULT_TITLE);

  const quiz: QuizInput = normalizeQuiz({
    title,
    description: `${parsed.questions.length} multiple-choice questions. Standard event mode: 60 seconds each.`,
    timingMode: "STANDARD",
    scoringMode: "SPEED",
    questions: parsed.questions,
  });
  const issues = validateQuizForPublish(quiz);
  if (issues.length) {
    console.error("The quiz has problems:\n" + issues.map((i) => `Q${(i.questionIndex ?? -1) + 1}: ${i.message}`).join("\n"));
    process.exit(1);
  }

  const existing = await prisma.quiz.findFirst({ where: { title }, select: { id: true } });
  if (existing) {
    console.log(`"${title}" already exists (${existing.id}). Nothing to do.`);
    return;
  }
  const created = await prisma.quiz.create({
    data: {
      title: quiz.title,
      description: quiz.description,
      timingMode: quiz.timingMode,
      scoringMode: quiz.scoringMode,
      status: draft ? "DRAFT" : "PUBLISHED",
      publishedAt: draft ? null : new Date(),
      questions: { create: quiz.questions.map((q, position) => ({ ...q, position })) },
    },
  });
  console.log(`Created "${title}" with ${quiz.questions.length} questions (${draft ? "draft" : "published"}): ${created.id}`);
}

main()
  .catch((error) => {
    console.error(error);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
