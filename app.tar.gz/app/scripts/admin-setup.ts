// One-time setup of the single administrator account.
//
//   ADMIN_USERNAME=host ADMIN_PASSWORD='a long passphrase' npm run admin:setup
//   npm run admin:setup                      (prompts for both, password hidden)
//   npm run admin:setup -- --reset-password  (replaces the existing password)
//
// There is no web sign-up. The database allows exactly one Admin row (CHECK id = 1).
import "dotenv/config";
import readline from "node:readline";
import { Writable } from "node:stream";
import { prisma } from "../src/lib/db";
import { hashPassword, passwordProblem } from "../src/lib/auth/password";

function ask(question: string, hidden = false): Promise<string> {
  let muted = false;
  const output = new Writable({
    write(chunk, encoding, cb) {
      if (!muted) process.stdout.write(chunk, encoding as BufferEncoding);
      cb();
    },
  });
  const rl = readline.createInterface({ input: process.stdin, output, terminal: true });
  return new Promise((resolve) => {
    rl.question(question, (answer) => {
      rl.close();
      if (hidden) process.stdout.write("\n");
      resolve(answer);
    });
    muted = hidden;
  });
}

async function main() {
  const reset = process.argv.includes("--reset-password");
  const existing = await prisma.admin.findUnique({ where: { id: 1 } });

  if (existing && !reset) {
    console.error(`An admin account already exists ("${existing.username}"). Only one is allowed.`);
    console.error("To set a new password, run: npm run admin:setup -- --reset-password");
    process.exit(1);
  }

  let username = (process.env.ADMIN_USERNAME ?? "").trim().toLowerCase();
  if (existing) username = existing.username;
  if (!username) username = (await ask("Admin username: ")).trim().toLowerCase();
  if (!/^[a-z0-9._-]{3,40}$/.test(username)) {
    console.error("Usernames are 3–40 characters: letters, numbers, dot, dash or underscore.");
    process.exit(1);
  }

  let password = process.env.ADMIN_PASSWORD ?? "";
  if (!password) {
    password = await ask("New admin password: ", true);
    const confirm = await ask("Repeat password: ", true);
    if (password !== confirm) {
      console.error("The passwords don't match.");
      process.exit(1);
    }
  }
  const problem = passwordProblem(password, username);
  if (problem) {
    console.error(`Password rejected: ${problem}`);
    process.exit(1);
  }

  const passwordHash = await hashPassword(password);
  if (existing) {
    await prisma.$transaction([
      prisma.admin.update({ where: { id: 1 }, data: { passwordHash, passwordChangedAt: new Date() } }),
      prisma.adminSession.deleteMany({}),
    ]);
    console.log(`Password updated for "${username}". All admin sessions were signed out.`);
  } else {
    await prisma.admin.create({ data: { id: 1, username, passwordHash } });
    console.log(`Admin account "${username}" created. Remove ADMIN_PASSWORD from your environment now.`);
  }
}

main()
  .catch((error) => {
    console.error(error instanceof Error ? error.message : error);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
