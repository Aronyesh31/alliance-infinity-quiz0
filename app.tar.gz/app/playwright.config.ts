import { defineConfig, devices } from "@playwright/test";

// End-to-end tests drive the real app: Next.js on :3000 and the realtime server
// on :4000, both pointing at a database with the admin account created.
// Set E2E_ADMIN_USERNAME / E2E_ADMIN_PASSWORD to that account.
const executablePath = process.env.PLAYWRIGHT_CHROMIUM_PATH || undefined;

export default defineConfig({
  testDir: "tests/e2e",
  timeout: 120_000,
  expect: { timeout: 20_000 },
  fullyParallel: false,
  workers: 1,
  reporter: [["list"]],
  use: {
    baseURL: process.env.E2E_BASE_URL ?? "http://localhost:3000",
    trace: "retain-on-failure",
    launchOptions: executablePath ? { executablePath, args: ["--no-sandbox", "--disable-dev-shm-usage"] } : undefined,
  },
  projects: [{ name: "chromium", use: { ...devices["Desktop Chrome"] } }],
  webServer: process.env.E2E_BASE_URL
    ? undefined
    : [
        { command: "npm run start", url: "http://localhost:3000/api/health", reuseExistingServer: true, timeout: 120_000 },
        { command: "npm run realtime:start", url: "http://localhost:4000/healthz", reuseExistingServer: true, timeout: 60_000 },
      ],
});
