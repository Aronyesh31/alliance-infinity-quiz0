# ALLIANCE × INFINITY CLUB — Live Quiz Platform

A live, team-based quiz platform for a one-day university competition of ~400 teams.
One admin runs the event; teams join on their phones with a game PIN; every question
runs on a strict, server-authoritative 60-second clock and advances on its own.

- **Team phones**: join with PIN + team name → lobby → questions → results → final standing
- **Projector**: `/present/{gameId}` — PIN, QR code, live team list, question + countdown, answer distribution, leaderboard, podium
- **Admin**: quiz builder (with text import), game control room, results, CSV export, settings

Quizzes can be written in the admin quiz builder or imported from text. Quiz files that
contain answer keys are **never committed**: keep them in the git-ignored `private/` folder and
load them with `npm run seed:quiz -- private/your-quiz.txt "Title"`.

---

## Architecture

```
 Phones / projector / admin browser
        │  HTTPS (pages, join, admin API)            │  WebSocket (live game)
        ▼                                            ▼
 ┌──────────────────────────┐   signed notify   ┌──────────────────────────────┐
 │ Next.js 16 app (Vercel)  │ ────────────────▶ │ Realtime server (Socket.IO)  │
 │ • pages + API routes     │   HMAC, 30 s skew │ • ONE persistent Node process│
 │ • admin auth (Argon2id)  │                   │   (Render / Railway / Fly)   │
 │ • join, quiz CRUD, CSV   │ ◀── 60 s ticket ─ │ • game clock & state machine │
 │ • issues socket tickets  │   (HMAC-signed)   │ • answer intake & scoring    │
 └────────────┬─────────────┘                   └──────────────┬───────────────┘
              │                Prisma 7 + pg                     │
              └──────────────────────┬──────────────────────────┘
                                     ▼
                         Neon PostgreSQL (single source of truth)
```

**Why two services?** Vercel functions are short-lived and can't hold 400 WebSockets
or run a timer. The game clock lives in one long-running Socket.IO process; everything
else (pages, joining, admin CRUD, exports) is ordinary serverless Next.js.

**How the browser authenticates to the realtime server.** Session credentials live in
HTTP-only cookies on the app's origin. The browser calls `POST /api/realtime/ticket`;
the app verifies the cookie and returns a **60-second HMAC-signed ticket**
(`REALTIME_SHARED_SECRET`) used only for the socket handshake. Tokens never appear in URLs.

### The 60-second clock (server-authoritative)

1. On opening a question the realtime server fixes `startedAt` and `deadline = startedAt + 60 s`,
   **persists both**, then broadcasts them with its current time.
2. Every client estimates its offset from the server clock (5-sample `time:sync`, lowest RTT)
   and draws the same countdown. Clients never decide anything.
3. An answer counts only if the server **receives** it while the question is open and
   `receivedAt ≤ deadline` (plus `ANSWER_GRACE_MS`, default **0**). The DB enforces one
   answer per team per question (`UNIQUE(teamId, sessionQuestionId)`).
4. A timer fires at the deadline: intake stops, in-flight writes finish, results are
   revealed, and after `revealSeconds` (default 5) the next question opens **automatically**.
   A 1-second watchdog backs up the timer.
5. The correct answer is never sent to teams or the projector before the deadline.
6. Every transition is persisted. If the realtime server restarts mid-question it reloads
   the game and closes the question at the **original** deadline.
7. **Single leader**: a Postgres advisory lock ensures only one realtime process runs game
   clocks. During a zero-downtime redeploy the new instance waits until the old one exits.

**Scoring** (server-side only, never negative):
- *Speed and accuracy* (default): correct = 500–1000 points, linear in response time
  (`1000 × (1 − t/60s ÷ 2)`); wrong or no answer = 0.
- *Accuracy only*: correct = full points.
- Ranking: score ↓, then correct answers ↓, then total time on correct answers ↑. Exact ties share a rank.

**Pause/resume** (emergency only) freezes the clock for every team equally; elapsed time
excludes the pause. **End question now** closes the question for everyone at once.

---

## Requirements coverage

| Requirement | Where |
|---|---|
| Exactly one admin | `Admin.id` has `CHECK (id = 1)`; `npm run admin:setup` refuses a second account; no sign-up route |
| Admin auth | Argon2id (19 MiB, t=2); 12 h DB sessions; `HttpOnly; Secure; SameSite=Strict; __Host-` cookie; logout deletes the session; 10 failed logins / 15 min / IP; timing-safe for unknown users |
| CSRF | Origin check on every mutating route + SameSite cookies + JSON-only bodies |
| Server-side authorization | `requireAdminPage` / `requireAdminApi` on every admin page and API; realtime re-checks the admin session on every command |
| PIN | 8-digit crypto-random (`crypto.randomInt`), unique; 100 failed lookups / 10 min / IP |
| Joining | Unique normalised names (case/space/punctuation-insensitive, invisible chars stripped), 2–24 chars, markup rejected; capacity enforced atomically in one SQL statement; refresh/rejoin restores the same team; one active device per team |
| Same questions, same order | Questions are frozen into `SessionQuestion` when a game is created |
| Strict 60 s, auto-advance | Standard event mode locks every question at 60 s; see "The 60-second clock" |
| One answer per team | In-memory claim + DB unique index; duplicates acknowledged with the original choice |
| Live leaderboard | Computed at every reveal; projector shows top 5 / top 10; teams see only their own rank (toggle) |
| Privacy | Projector/teams receive public data only; detailed results and CSV are admin-only |
| CSV export | Rankings and every individual answer; formula-injection safe; UTF-8 BOM for Excel |
| 400 teams | Load-tested — see below |

---

## Local development

Requirements: Node 20.19+ (22 recommended), PostgreSQL 15+ (or a Neon branch).

```bash
npm install
cp .env.example .env            # fill in DATABASE_URL, DIRECT_URL, APP_ORIGIN, secret…
npx prisma migrate deploy        # create tables
npm run admin:setup              # prompts for username + password (or set ADMIN_USERNAME/ADMIN_PASSWORD)
npm run seed:quiz -- private/quiz.txt "Round 1"   # optional: import a text quiz (published, 60 s each)

npm run realtime:dev             # terminal 1 → http://localhost:4000
npm run dev                      # terminal 2 → http://localhost:3000
```

Local `.env` example:

```
DATABASE_URL="postgresql://user:pass@localhost:5432/aic_quiz"
DIRECT_URL="postgresql://user:pass@localhost:5432/aic_quiz"
APP_ORIGIN="http://localhost:3000"
NEXT_PUBLIC_REALTIME_URL="http://localhost:4000"
REALTIME_SHARED_SECRET="any-random-string-of-32-or-more-characters"
```

## Tests

| Command | What it covers |
|---|---|
| `npm run test:unit` | Scoring, ranking, PIN, team-name normalisation, tickets, internal signatures, CSV escaping, quiz validation, text import, Argon2id |
| `npm run test:integration` | Real realtime server + Postgres (set `TEST_DATABASE_URL` to an empty test database): first-run admin setup (one admin only, race-safe); full auto-advancing game with 30 teams, exact deadlines, one answer per team, invalid/duplicate/late answers, server-side points, final ranks; pause/resume; **crash recovery mid-question**; socket auth, team removal, admin revocation, one device per team |
| `npm run test:e2e` | Playwright in a real browser: admin login, quiz import + publish, game creation, two phones join, duplicate name rejected, auto-advance, refresh restores session, results + CSV, non-admins blocked. Needs `E2E_ADMIN_USERNAME` / `E2E_ADMIN_PASSWORD` |
| `npm run load:sockets -- --teams 400` | Full-stack load test (HTTP join → ticket → socket → answers) |
| `npm run load:k6` | k6 burst test of the HTTP join path (`-e BASE=… -e PIN=…`) |

### Load test results (measured)

Run on a single 2-vCPU / 8 GB machine: one `next start` process, one realtime process,
local PostgreSQL 16, all 400 clients from the same machine. **All 400 teams joined in the
same second** (a far harsher burst than a real lobby).

| 400 teams, 3 questions | Result |
|---|---|
| Teams joined / capacity overflow refused | 400 / 400, yes |
| Sockets connected | 400 / 400 |
| Answers accepted and stored | 1,200 / 1,200, no errors |
| Answer acknowledgement | p50 4 ms · p95 10 ms · p99 19 ms |
| Question broadcast to all phones | p99 114 ms after opening |
| Results broadcast after the deadline | p99 34 ms |
| Game wall time | 55.3 s for 54 s of scheduled time |
| Realtime server memory | ~200 MB RSS |

Headroom check at **800 teams**: 800/800 joined, 1,600/1,600 answers accepted, results
reached every phone within 98 ms (p99) of the deadline.

> These numbers come from local infrastructure. **Before the event, deploy the real stack
> and run `npm run load:sockets -- --teams 400 --base https://… --realtime https://…` from
> a machine on the campus network** (raise `RATE_LIMIT_JOIN_PER_IP` for that run, since all
> simulated teams share one IP). That is the only test that proves your hosting capacity.

---

## Deployment

### 1. Neon (database)
1. Create a project in the region nearest your users (e.g. `ap-southeast-1` Singapore for India).
2. Copy both connection strings: **pooled** (host contains `-pooler`) → `DATABASE_URL`;
   **direct** → `DIRECT_URL`.
3. From your machine: `DIRECT_URL=… DATABASE_URL=… npx prisma migrate deploy`
4. Create the admin account — either `DATABASE_URL=… npm run admin:setup` from a computer, or the
   **web setup** below. Import quizzes with `npm run seed:quiz` or in the admin quiz builder.

### First-run admin setup without a terminal
Set `ADMIN_SETUP_CODE` (16+ random characters) on the app. While no admin exists, `/admin/login`
redirects to `/admin/setup`, where whoever has the code chooses the username and password. It
works exactly once (the database allows a single admin row); afterwards the page redirects to
sign-in and the code is useless. Remove the variable after setup if you like.

### 2. Realtime server (Render — or Railway/Fly using `Dockerfile.realtime`)
1. New **Web Service** from this repo (or use `render.yaml`). Paid instance (free ones sleep), **1 instance**, same region as Neon.
2. Build `npm ci --omit=dev` · Start `npm run realtime:start` · Health check `/healthz`.
3. Env: `DATABASE_URL`, `DIRECT_URL`, `APP_ORIGIN` (your Vercel URL), `REALTIME_SHARED_SECRET`, optionally `REALTIME_EXTRA_ORIGINS` (comma-separated, e.g. a custom domain).
4. Note the public URL, e.g. `https://aic-realtime.onrender.com`.

### 3. Next.js app (Vercel)
1. Import the repo. Framework preset: Next.js. Node 22.
2. Env (Production): `DATABASE_URL` (pooled), `DIRECT_URL`, `APP_ORIGIN` (e.g. `https://quiz.example.edu`),
   `NEXT_PUBLIC_REALTIME_URL` (realtime URL from step 2), `REALTIME_SHARED_SECRET` (**same value** as the realtime server).
3. Optional: Build Command `npm run build:deploy` to apply migrations on every deploy.
4. Deploy, then open `/admin/settings` — both **Database** and **Realtime server** must be green.

`NEXT_PUBLIC_REALTIME_URL` is baked in at build time (also used in the Content-Security-Policy),
so redeploy the app if it changes.

### Environment variables

| Variable | App | Realtime | Notes |
|---|:-:|:-:|---|
| `DATABASE_URL` | ✓ | ✓ | Neon pooled URL |
| `DIRECT_URL` | migrations | ✓ | Neon direct URL (advisory lock + migrations) |
| `APP_ORIGIN` | ✓ | ✓ | Exact public origin of the app, no trailing slash |
| `NEXT_PUBLIC_REALTIME_URL` | ✓ | | Public realtime URL |
| `REALTIME_INTERNAL_URL` | optional | | If the app reaches realtime by another URL |
| `REALTIME_SHARED_SECRET` | ✓ | ✓ | ≥ 32 chars, identical on both |
| `REALTIME_EXTRA_ORIGINS` | | optional | Extra allowed browser origins |
| `DB_POOL_MAX` | optional | optional | Default 5 (app) — use 10 on realtime |
| `ANSWER_GRACE_MS` | | optional | Default 0 (strict deadline) |
| `RATE_LIMIT_*` | optional | | See `.env.example` |
| `ADMIN_SETUP_CODE` | optional | | One-time code for `/admin/setup` (16+ chars) |
| `ADMIN_USERNAME` / `ADMIN_PASSWORD` | setup only | | Remove after `admin:setup` |

---

### Running on free plans (Render Free + Neon Free)
Both services can run on Render's free web services with Neon's free database. Trade-offs:
- **Free Render services sleep after 15 minutes without traffic** and take about a minute to wake.
  Open the site and the presentation screen **10 minutes before the event** to wake both; live
  traffic keeps them awake during the game.
- Free instances have 0.1 CPU and 512 MB RAM. The realtime server used ~200 MB with 400 teams in
  testing, but CPU is tight: **run the 400-team load test against the free deployment** before the
  event. If join or page-load times are poor, move the website to Vercel's free Hobby plan (or upgrade
  the realtime service to Starter) — no code changes are needed.
- Neon Free scales the database to zero when idle (first query after a pause takes ~0.5 s) and allows
  autoscaling up to 2 CU.

## Event-day runbook

1. **Day before**: deploy, check `/admin/settings` is all green, run the 400-team load test against production, then delete the load-test games from **Games**.
2. Sign in on the admin laptop. **Games → New game** with your quiz (capacity 500, results 5 s).
3. Open **Presentation screen** on the projector machine (it needs no login and shows only public information).
4. Teams scan the QR code or go to the site and type the PIN. Watch the team count in the control room; remove any inappropriate names.
5. Press **Start game**. Nothing else is needed — 30 questions × 60 s + 5 s results ≈ 33 minutes.
6. Emergencies: **Pause** freezes the clock for everyone; **End question now** closes the current question; **End game** stops and saves final ranks.
7. Afterwards: **Results → Rankings (CSV)** and **Every answer (CSV)**.

Notes
- Campus Wi-Fi often puts many phones behind one public IP; join limits are generous on purpose (`RATE_LIMIT_JOIN_PER_IP`, default 3000 per 10 min). Wrong-PIN guesses are limited tightly.
- A team that loses connection rejoins automatically; answers already submitted are kept. Opening the game on a second device moves the team there (one device per team).
- Late joining is off by default; turn on **Allow joining after the start** in the game settings if needed.

## Security notes
- Secrets only via environment variables; nothing sensitive is in the repo or client bundle.
- Every admin API verifies the DB-backed session; every mutation checks `Origin`.
- Sockets: ticket-authenticated; payloads validated with Zod; per-socket rate limits; 16 KB max message.
- Team names are rendered as text by React and restricted to a safe character set; CSV cells are formula-escaped.
- Uploaded images are type-checked by magic bytes (PNG/JPEG/WebP/GIF, ≤ 2 MB) and served with `nosniff` and a sandboxed CSP.
- Headers: CSP, `frame-ancestors 'none'`, HSTS (production), `nosniff`, strict referrer policy.

## Branding
The infinity mark, wordmark, favicon and visual system are original to this project.
The Alliance University crest in `public/brand/` is the file supplied by the organisers and
is shown unaltered in the landing footer and on the final results screen — confirm you have
permission to use it before going live, or delete the file and the two `<AllianceCrest>` usages.

## Project layout
```
src/app/            pages + API routes (Next.js App Router)
src/components/     brand, game (team/projector), admin, ui (shadcn-style primitives)
src/lib/            config, auth, validation, scoring, ranking, CSV, realtime protocol/client
realtime/           Socket.IO server: engine (state machine + clock), repo, leader lock
prisma/             schema + migrations
scripts/            admin-setup, seed-maths-quiz (imports text quizzes from private/)
private/            git-ignored: quiz files with answer keys
tests/              unit, integration (Postgres), e2e (Playwright)
load/               socket-load.ts (full stack), k6-join.js (HTTP)
```
