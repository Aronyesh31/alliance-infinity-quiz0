// Full-stack load test: N teams join over HTTP, open realtime sockets, and
// answer every question while the server runs the clock.
//
//   E2E_ADMIN_USERNAME=host E2E_ADMIN_PASSWORD=... npm run load:sockets -- --teams 400
//
// Options: --teams 400  --questions 3  --seconds 15  --reveal 3
//          --base http://localhost:3000  --realtime http://localhost:4000
//
// Run it from a machine near the servers and watch CPU/memory on the hosts.
// Every team joins from one IP here, so raise RATE_LIMIT_JOIN_PER_IP if needed.
import { io, type Socket } from "socket.io-client";
import type { Ack, PublicSnapshot } from "../src/lib/realtime/protocol";

function arg(name: string, fallback: string) {
  const i = process.argv.indexOf(`--${name}`);
  return i > 0 && process.argv[i + 1] ? process.argv[i + 1] : fallback;
}

const TEAMS = Number(arg("teams", "400"));
const QUESTIONS = Number(arg("questions", "3"));
const SECONDS = Number(arg("seconds", "15"));
const REVEAL = Number(arg("reveal", "3"));
const BASE = arg("base", "http://localhost:3000");
const REALTIME = arg("realtime", process.env.NEXT_PUBLIC_REALTIME_URL ?? "http://localhost:4000");
const USER = process.env.E2E_ADMIN_USERNAME ?? "";
const PASS = process.env.E2E_ADMIN_PASSWORD ?? "";

const pct = (xs: number[], p: number) => {
  if (xs.length === 0) return NaN;
  const s = [...xs].sort((a, b) => a - b);
  return s[Math.min(s.length - 1, Math.floor((p / 100) * s.length))];
};
const summary = (label: string, xs: number[]) =>
  `${label.padEnd(34)} n=${String(xs.length).padStart(5)}  p50=${pct(xs, 50).toFixed(0).padStart(5)} ms  p95=${pct(xs, 95).toFixed(0).padStart(5)} ms  p99=${pct(xs, 99).toFixed(0).padStart(5)} ms  max=${Math.max(...xs).toFixed(0).padStart(5)} ms`;

async function http(path: string, init: { method?: string; body?: unknown; cookie?: string } = {}) {
  const res = await fetch(`${BASE}${path}`, {
    method: init.method ?? (init.body ? "POST" : "GET"),
    headers: {
      ...(init.body ? { "content-type": "application/json" } : {}),
      origin: BASE,
      ...(init.cookie ? { cookie: init.cookie } : {}),
    },
    body: init.body ? JSON.stringify(init.body) : undefined,
  });
  const cookie = res.headers
    .getSetCookie()
    .map((c) => c.split(";")[0])
    .filter((c) => !c.endsWith("="))
    .join("; ");
  const data = (await res.json().catch(() => ({}))) as Record<string, unknown>;
  return { status: res.status, data, cookie };
}

async function main() {
  if (!USER || !PASS) throw new Error("Set E2E_ADMIN_USERNAME and E2E_ADMIN_PASSWORD.");
  console.log(`Load test: ${TEAMS} teams, ${QUESTIONS} questions × ${SECONDS}s, results ${REVEAL}s\n  app ${BASE}\n  realtime ${REALTIME}\n`);

  // ── Admin: sign in, create a quiz and a game ──
  const login = await http("/api/admin/login", { body: { username: USER, password: PASS } });
  if (login.status !== 200) throw new Error(`admin login failed: ${login.status} ${JSON.stringify(login.data)}`);
  const adminCookie = login.cookie;
  const questions = Array.from({ length: QUESTIONS }, (_, i) => ({
    type: "MULTIPLE_CHOICE",
    text: `Load question ${i + 1}: which letter is correct?`,
    choices: ["Alpha", "Bravo", "Charlie", "Delta"],
    correctIndex: i % 4,
    imageId: null,
    timeLimitSec: SECONDS,
    points: 1000,
    explanation: "",
  }));
  const quiz = await http("/api/admin/quizzes", {
    cookie: adminCookie,
    body: { mode: "publish", quiz: { title: `Load test ${new Date().toISOString()}`, description: "", timingMode: "CUSTOM", scoringMode: "SPEED", questions } },
  });
  if (quiz.status !== 201) throw new Error(`quiz create failed: ${JSON.stringify(quiz.data)}`);
  const game = await http("/api/admin/sessions", {
    cookie: adminCookie,
    body: {
      quizId: quiz.data.id,
      settings: { capacity: TEAMS, revealSeconds: REVEAL, showTeamStanding: true, showAnswerFeedback: true, allowLateJoin: false },
    },
  });
  if (game.status !== 201) throw new Error(`game create failed: ${JSON.stringify(game.data)}`);
  const sessionId = String(game.data.id);
  const pin = String(game.data.pin);
  console.log(`Game ${sessionId}, PIN ${pin}`);

  // ── Phase 1: every team joins at once ──
  const joinLatency: number[] = [];
  const joinErrors: string[] = [];
  const t0 = Date.now();
  const joined = await Promise.all(
    Array.from({ length: TEAMS }, async (_, i) => {
      const s = Date.now();
      const r = await http("/api/join", { body: { pin, teamName: `Load Team ${i + 1}` } }).catch((e) => ({ status: 0, data: { message: String(e) }, cookie: "" }));
      joinLatency.push(Date.now() - s);
      if (r.status !== 201) {
        joinErrors.push(`${r.status} ${String(r.data.message ?? "")}`);
        return null;
      }
      return r.cookie;
    }),
  );
  const joinWall = Date.now() - t0;
  const cookies = joined.filter((c): c is string => !!c);
  // One more join must be refused: the game is at capacity.
  const overflow = await http("/api/join", { body: { pin, teamName: "One Too Many" } });

  // ── Phase 2: tickets and sockets ──
  const ticketLatency: number[] = [];
  const connectLatency: number[] = [];
  const sockets: Socket[] = [];
  const answerLatency: number[] = [];
  const answerErrors: string[] = [];
  const openLag: number[] = [];
  const revealLag: number[] = [];
  const finishedAt: number[] = [];
  let accepted = 0;

  const t1 = Date.now();
  await Promise.all(
    cookies.map(async (cookie, i) => {
      const ts = Date.now();
      const ticket = await http("/api/realtime/ticket", { cookie, body: { role: "team" } });
      ticketLatency.push(Date.now() - ts);
      if (ticket.status !== 200) {
        answerErrors.push(`ticket ${ticket.status}`);
        return;
      }
      const cs = Date.now();
      const socket = io(REALTIME, { auth: { ticket: ticket.data.ticket }, reconnection: true, extraHeaders: { origin: BASE } });
      sockets.push(socket);
      const answered = new Set<number>();
      const seen = new Set<string>();
      socket.on("state", (s: PublicSnapshot) => {
        const key = `${s.state}:${s.currentIndex}`;
        if (!seen.has(key)) {
          seen.add(key);
          if (s.state === "QUESTION" && s.questionStartedAt) openLag.push(Date.now() - s.questionStartedAt);
          if (s.state === "REVEAL" && s.deadline) revealLag.push(Date.now() - s.deadline);
          if (s.state === "FINISHED") finishedAt.push(Date.now());
        }
        if (s.state !== "QUESTION" || answered.has(s.currentIndex)) return;
        answered.add(s.currentIndex);
        const q = s.currentIndex;
        // Spread answers over the first ~70% of the window, 65% correct.
        const delay = Math.random() * SECONDS * 700;
        setTimeout(async () => {
          const choice = Math.random() < 0.65 ? q % 4 : (q + 1 + Math.floor(Math.random() * 3)) % 4;
          const sent = Date.now();
          try {
            const ack: Ack = await socket.timeout(10_000).emitWithAck("answer:submit", { questionIndex: q, choiceIndex: choice });
            answerLatency.push(Date.now() - sent);
            if (ack.ok) accepted++;
            else answerErrors.push(ack.code);
          } catch {
            answerErrors.push("timeout");
          }
        }, delay);
      });
      await new Promise<void>((resolve) => {
        socket.once("connect", () => {
          connectLatency.push(Date.now() - cs);
          resolve();
        });
        socket.once("connect_error", (e) => {
          answerErrors.push(`connect ${e.message}`);
          resolve();
        });
      });
    }),
  );
  const connectWall = Date.now() - t1;

  // Two presentation screens, like a projector and a backup.
  for (let i = 0; i < 2; i++) sockets.push(io(REALTIME, { auth: { role: "screen", sessionId }, extraHeaders: { origin: BASE } }));

  // ── Phase 3: the admin starts the game; everything else is automatic ──
  const adminTicket = await http("/api/realtime/ticket", { cookie: adminCookie, body: { role: "admin" } });
  const admin = io(REALTIME, { auth: { ticket: adminTicket.data.ticket }, extraHeaders: { origin: BASE } });
  await new Promise<void>((r) => admin.once("connect", () => r()));
  await admin.emitWithAck("admin:watch", { sessionId });
  let maxConnected = 0;
  admin.on("admin:snapshot", (s: { connectedCount: number }) => (maxConnected = Math.max(maxConnected, s.connectedCount)));
  await new Promise((r) => setTimeout(r, 1500));
  const start: Ack = await admin.emitWithAck("admin:command", { sessionId, command: { type: "start" } });
  if (!start.ok) throw new Error(`start failed: ${start.message}`);
  const gameStart = Date.now();

  const expectedMs = QUESTIONS * (SECONDS + REVEAL) * 1000;
  await new Promise<void>((resolve) => {
    const timer = setInterval(() => {
      if (finishedAt.length >= sockets.length - 2 || Date.now() - gameStart > expectedMs + 30_000) {
        clearInterval(timer);
        resolve();
      }
    }, 250);
  });
  await new Promise((r) => setTimeout(r, 1000));
  const health = await fetch(`${REALTIME}/healthz`).then((r) => r.json());

  // ── Verify server-side results ──
  const csv = await fetch(`${BASE}/api/admin/sessions/${sessionId}/export?kind=answers`, { headers: { cookie: adminCookie } }).then((r) => r.text());
  const storedAnswers = csv.trim().split(/\r?\n/).length - 1;

  for (const s of sockets) s.disconnect();
  admin.disconnect();

  const errorCounts = (xs: string[]) => Object.entries(xs.reduce<Record<string, number>>((m, e) => ((m[e] = (m[e] ?? 0) + 1), m), {}));
  console.log("\n── Results ─────────────────────────────────────────────────────────────");
  console.log(`Teams joined:                      ${cookies.length}/${TEAMS} in ${joinWall} ms ${joinErrors.length ? `errors: ${JSON.stringify(errorCounts(joinErrors))}` : ""}`);
  console.log(`Join beyond capacity refused:      ${overflow.status === 409 ? "yes" : `NO (${overflow.status})`}`);
  console.log(`Sockets connected:                 ${connectLatency.length}/${cookies.length} in ${connectWall} ms (peak seen by admin: ${maxConnected})`);
  console.log(summary("HTTP join", joinLatency));
  console.log(summary("HTTP ticket", ticketLatency));
  console.log(summary("Socket connect", connectLatency));
  console.log(summary("Question broadcast lag", openLag));
  console.log(summary("Results broadcast lag after deadline", revealLag));
  console.log(summary("Answer acknowledgement", answerLatency));
  console.log(`Answers accepted:                  ${accepted}/${cookies.length * QUESTIONS} ${answerErrors.length ? `errors: ${JSON.stringify(errorCounts(answerErrors))}` : "(no errors)"}`);
  console.log(`Answers stored in database:        ${storedAnswers}`);
  console.log(`Teams that saw the final screen:   ${finishedAt.length}/${connectLatency.length}`);
  console.log(`Game wall time:                    ${((Date.now() - gameStart) / 1000).toFixed(1)} s (expected ≈ ${(expectedMs / 1000).toFixed(0)} s)`);
  console.log(`Realtime server after test:        ${JSON.stringify(health)}`);
  const pass =
    cookies.length === TEAMS &&
    overflow.status === 409 &&
    connectLatency.length === TEAMS &&
    accepted === TEAMS * QUESTIONS &&
    storedAnswers === accepted &&
    finishedAt.length === TEAMS &&
    pct(revealLag, 99) < 1000;
  console.log(`\nOverall: ${pass ? "PASS" : "FAIL"}`);
  process.exit(pass ? 0 : 1);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
