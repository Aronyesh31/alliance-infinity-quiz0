// k6 load test for the HTTP side: teams joining a game in a burst.
// (The realtime/socket side is covered by load/socket-load.ts.)
//
//   k6 run -e BASE=https://quiz.example.edu -e PIN=12345678 load/k6-join.js
//
// Create a game with enough capacity first. Every VU joins with a unique name
// once, then exchanges its cookie for a realtime ticket.
import http from "k6/http";
import { check } from "k6";
import { Trend } from "k6/metrics";

const BASE = __ENV.BASE || "http://localhost:3000";
const PIN = __ENV.PIN;
const joinTime = new Trend("join_ms", true);

export const options = {
  scenarios: {
    burst: { executor: "per-vu-iterations", vus: Number(__ENV.TEAMS || 400), iterations: 1, maxDuration: "2m" },
  },
  thresholds: {
    checks: ["rate>0.99"],
    join_ms: ["p(95)<3000"],
  },
};

export default function () {
  const headers = { "content-type": "application/json", origin: BASE };
  const name = `k6 Team ${__VU}-${Date.now() % 100000}`;
  const res = http.post(`${BASE}/api/join`, JSON.stringify({ pin: PIN, teamName: name }), { headers });
  joinTime.add(res.timings.duration);
  check(res, { "joined (201)": (r) => r.status === 201 });
  const ticket = http.post(`${BASE}/api/realtime/ticket`, JSON.stringify({ role: "team" }), { headers });
  check(ticket, { "ticket issued": (r) => r.status === 200 && !!r.json("ticket") });
}
